import React from 'react';

export const ChatBot: React.FC = () => {
    return null;
};
