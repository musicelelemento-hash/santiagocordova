
// Componente dummy para prevenir errores de importación si existen referencias cacheadas
import React from 'react';

export const GeminiScreen = () => {
    return null;
};
export default GeminiScreen;
