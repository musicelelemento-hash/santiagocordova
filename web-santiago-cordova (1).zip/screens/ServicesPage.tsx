
import React, { useState, useEffect } from 'react';
import { Check, ShoppingCart, ArrowRight, X, Trash2, CheckCircle, User, Phone, CreditCard, Mail, Star, TrendingUp, MapPin, Menu, MessageCircle, FileKey, Laptop, ShieldCheck, Briefcase, Package, Activity, Globe, DollarSign, Zap, Crown, Lock } from 'lucide-react';
import { Logo } from '../components/Logo';
import { Modal } from '../components/Modal';
import { AuthModal } from '../components/AuthModal';
import { OrderItem, WebOrder, PublicUser } from '../types';
import { v4 as uuidv4 } from 'uuid';

interface ServicesPageProps {
    onAdminAccess: () => void;
    onSubmitOrder: (order: WebOrder) => void;
    onNavigateToHome: () => void;
    currentUser: PublicUser | null;
    onLogin: (user: PublicUser) => void;
    onLogout: () => void;
}

export const ServicesPage: React.FC<ServicesPageProps> = ({ onAdminAccess, onSubmitOrder, onNavigateToHome, currentUser, onLogin, onLogout }) => {
    const [scrolled, setScrolled] = useState(false);
    const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
    const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
    const [activeCategory, setActiveCategory] = useState<'tax' | 'tech' | 'special'>('tax'); 
    
    // Cart State
    const [cart, setCart] = useState<OrderItem[]>([]);
    const [isCartOpen, setIsCartOpen] = useState(false);
    const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
    
    // Checkout Form State
    const [clientName, setClientName] = useState('');
    const [clientPhone, setClientPhone] = useState('');
    const [clientEmail, setClientEmail] = useState('');
    const [clientRuc, setClientRuc] = useState('');
    const [orderSuccess, setOrderSuccess] = useState(false);

    const phoneNumber = "593978980722"; 
    const whatsappLink = `https://wa.me/${phoneNumber}`;

    useEffect(() => {
        const handleScroll = () => setScrolled(window.scrollY > 50);
        window.addEventListener('scroll', handleScroll);
        return () => window.removeEventListener('scroll', handleScroll);
    }, []);

    useEffect(() => {
        if (currentUser) {
            setClientName(currentUser.name);
            setClientEmail(currentUser.email);
        }
    }, [currentUser]);

    const handleAddToCart = (service: any) => {
        const newItem: OrderItem = {
            id: uuidv4(),
            title: service.title,
            price: parseFloat(service.price),
            quantity: 1
        };
        setCart([...cart, newItem]);
        // Don't open cart automatically on mobile to keep flow fluid, just show the floating bar
        if (window.innerWidth > 768) {
            setIsCartOpen(true);
        }
    };

    const removeFromCart = (id: string) => {
        setCart(cart.filter(item => item.id !== id));
    };

    const cartTotal = cart.reduce((sum, item) => sum + item.price, 0);

    const handleCheckoutSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!clientName || !clientPhone) {
            alert("Nombre y Teléfono son obligatorios");
            return;
        }

        const newOrder: WebOrder = {
            id: uuidv4(),
            clientName,
            clientPhone,
            clientEmail,
            clientRuc,
            items: cart,
            total: cartTotal,
            status: 'pending',
            createdAt: new Date().toISOString()
        };

        onSubmitOrder(newOrder);
        setOrderSuccess(true);
        setCart([]);
        setTimeout(() => {
            setOrderSuccess(false);
            setIsCheckoutOpen(false);
            setIsCartOpen(false);
            if (!currentUser) {
                setClientName('');
                setClientEmail('');
            }
            setClientPhone('');
            setClientRuc('');
        }, 3000);
    };

    // --- DATA DEFINITION ---
    const plans = {
        tech: [
            {
                title: "Firma Electrónica",
                price: "35.00",
                description: "Token .P12 válido para facturación SRI, Quipux y trámites legales.",
                features: ["Vigencia 1 Año", "Entrega Inmediata", "Instalación Remota", "Soporte Técnico"],
                icon: FileKey,
                popular: false,
                color: "from-purple-500 to-indigo-500"
            },
            {
                title: "Pack Facturador",
                price: "55.00",
                originalPrice: "75.00",
                save: "20.00",
                description: "Sistema de facturación web ilimitado + Firma electrónica.",
                features: ["Firma Electrónica (1 Año)", "Facturación Ilimitada", "App Móvil", "Control de Inventario"],
                icon: Laptop,
                popular: true,
                color: "from-blue-500 to-cyan-500"
            }
        ],
        tax: [
            {
                title: "RIMPE Popular",
                price: "4.99",
                originalPrice: "8.99",
                save: "4.00",
                description: "Cumplimiento anual para pequeños negocios.",
                features: ["Declaración Renta Anual", "Reporte de Obligaciones", "Asesoría Básica"],
                icon: Star,
                popular: false,
                color: "from-slate-500 to-slate-700"
            },
            {
                title: "RIMPE Emprendedor",
                price: "15.00",
                originalPrice: "25.00",
                save: "10.00",
                description: "Gestión semestral para negocios en crecimiento.",
                features: ["IVA Semestral", "Renta Anual", "Anexo Transaccional", "Soporte Prioritario"],
                icon: TrendingUp,
                popular: true,
                color: "from-[#00A896] to-emerald-600"
            },
            {
                title: "Profesionales",
                price: "49.99",
                description: "Gestión mensual completa para servicios profesionales.",
                features: ["IVA Mensual", "Anexo Gastos Personales", "Devolución de Retenciones", "Planeación Fiscal"],
                icon: User,
                popular: false,
                color: "from-amber-400 to-orange-500"
            }
        ],
        special: [
            {
                title: "Devolución IVA",
                price: "15.00",
                description: "Trámite para Tercera Edad y Discapacidad.",
                features: ["Análisis de facturas", "Carga de solicitud", "Seguimiento hasta acreditación"],
                icon: DollarSign,
                popular: true,
                color: "from-green-500 to-emerald-700"
            },
            {
                title: "Patente Municipal",
                price: "25.00",
                description: "Declaración anual de patente y 1.5 por mil.",
                features: ["Cálculo de impuesto", "Generación de título", "Gestión de exoneraciones"],
                icon: MapPin,
                popular: false,
                color: "from-pink-500 to-rose-500"
            }
        ]
    };

    const activePlans = (plans as any)[activeCategory] || [];

    const CategoryButton = ({ id, label, icon: Icon }: { id: string, label: string, icon: any }) => (
        <button 
            onClick={() => { setActiveCategory(id as any); window.scrollTo({top: 300, behavior: 'smooth'}); }}
            className={`
                flex items-center gap-2 px-6 py-3 rounded-full text-xs font-black uppercase tracking-wider transition-all duration-500 flex-shrink-0 relative overflow-hidden
                ${activeCategory === id 
                    ? 'text-[#020617] shadow-[0_0_30px_rgba(0,168,150,0.6)] scale-105' 
                    : 'bg-white/5 text-slate-400 hover:text-white border border-white/10 hover:bg-white/10'
                }
            `}
        >
            {activeCategory === id && (
                <div className="absolute inset-0 bg-gradient-to-r from-[#00A896] to-emerald-400 animate-pulse-slow"></div>
            )}
            <span className="relative z-10 flex items-center gap-2">
                <Icon size={16} strokeWidth={2.5}/> {label}
            </span>
        </button>
    );

    return (
        <div className="min-h-screen bg-[#020617] font-body text-slate-200 selection:bg-[#00A896] selection:text-white overflow-x-hidden pb-20 md:pb-0">
            
            {/* Header / Nav */}
            <nav className={`fixed w-full z-50 transition-all duration-500 border-b ${scrolled ? 'bg-[#020617]/90 backdrop-blur-xl border-white/5 py-4' : 'bg-transparent py-6 border-transparent'}`}>
                <div className="max-w-7xl mx-auto px-6 flex justify-between items-center">
                    <button onClick={onNavigateToHome} className="flex items-center gap-3 group">
                        <div className={`p-2 rounded-xl transition-all ${scrolled ? 'bg-white/5 border border-white/10' : 'bg-white/10 border border-white/20'}`}>
                            <Logo className="w-6 h-6 text-white" />
                        </div>
                        <div className="text-left">
                            <span className="text-base font-display font-black tracking-tight leading-none block text-white">GESTIONES</span>
                        </div>
                    </button>
                    
                    <div className="hidden md:flex items-center gap-8">
                        <button onClick={onNavigateToHome} className="text-sm font-bold text-slate-400 hover:text-white transition-colors">Inicio</button>
                        <button onClick={() => setIsCartOpen(true)} className="relative flex items-center gap-2 text-sm font-bold text-white hover:text-[#00A896] transition-colors group">
                            <div className="relative">
                                <ShoppingCart size={20} className="group-hover:scale-110 transition-transform"/>
                                {cart.length > 0 && <span className="absolute -top-2 -right-2 bg-[#00A896] text-white text-[9px] font-black w-4 h-4 flex items-center justify-center rounded-full shadow-[0_0_10px_#00A896]">{cart.length}</span>}
                            </div>
                            <span>Carrito</span>
                        </button>
                        <a href={whatsappLink} target="_blank" rel="noopener noreferrer" className="px-6 py-2.5 bg-white/5 border border-white/10 text-white font-black rounded-xl hover:bg-white hover:text-[#020617] transition-all text-xs uppercase tracking-wider flex items-center gap-2">
                            <MessageCircle size={16}/> Asesoría
                        </a>
                    </div>
                    
                    <button onClick={() => setMobileMenuOpen(true)} className="md:hidden p-2 text-white"><Menu size={24}/></button>
                </div>
            </nav>

             {/* Mobile Menu Overlay */}
             {mobileMenuOpen && (
                <div className="fixed inset-0 z-[60] bg-[#020617] flex flex-col items-center justify-center space-y-8 animate-fade-in p-8">
                    <button className="absolute top-8 right-8 p-3 bg-white/10 rounded-full text-white" onClick={() => setMobileMenuOpen(false)}>
                        <X size={24}/>
                    </button>
                    <button onClick={() => { onNavigateToHome(); setMobileMenuOpen(false); }} className="text-3xl font-display font-black text-white">Inicio</button>
                    <button onClick={() => { setIsCartOpen(true); setMobileMenuOpen(false); }} className="text-3xl font-display font-black text-white">Ver Carrito ({cart.length})</button>
                    <button onClick={() => { onAdminAccess(); setMobileMenuOpen(false); }} className="text-sm font-bold text-slate-500 uppercase tracking-widest mt-8">Acceso Admin</button>
                </div>
            )}

            {/* Hero Section */}
            <div className="relative pt-40 pb-32 px-6 overflow-hidden text-center">
                 {/* Background FX */}
                 <div className="absolute top-0 left-0 w-full h-full bg-[#020617] z-0">
                    <div className="absolute top-[-20%] left-[-10%] w-[80%] h-[80%] bg-blue-600/10 rounded-full blur-[120px] animate-pulse-slow"></div>
                    <div className="absolute bottom-[-20%] right-[-10%] w-[70%] h-[70%] bg-[#00A896]/10 rounded-full blur-[130px] animate-pulse-slow" style={{animationDelay: '1s'}}></div>
                 </div>

                 <div className="relative z-10 max-w-4xl mx-auto">
                    <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/5 border border-white/10 text-white text-[10px] font-black uppercase tracking-widest mb-6 backdrop-blur-md shadow-[0_0_20px_rgba(255,255,255,0.05)]">
                        <Globe size={12} className="text-[#00A896]"/> Servicios Digitales 2026
                    </div>
                    <h1 className="text-4xl md:text-7xl font-display font-black text-white mb-6 tracking-tight leading-[1.1]">
                        Soluciones a su <br/> <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#00A896] to-emerald-300">Medida.</span>
                    </h1>
                 </div>
            </div>

            {/* --- STICKY CATEGORY NAV (MOBILE OPTIMIZED) --- */}
            <div className="sticky top-[80px] z-40 py-6 -mt-10 mb-8 overflow-x-auto no-scrollbar px-6 flex justify-center pointer-events-none">
                <div className="inline-flex gap-2 p-1.5 bg-[#020617]/80 backdrop-blur-xl border border-white/10 shadow-2xl rounded-full pointer-events-auto">
                    <CategoryButton id="tax" label="Tributarios" icon={Briefcase} />
                    <CategoryButton id="tech" label="Firma & Fact." icon={Laptop} />
                    <CategoryButton id="special" label="Trámites" icon={Activity} />
                </div>
            </div>

            {/* Plans Grid */}
            <div className="max-w-7xl mx-auto px-6 relative z-20 pb-40">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    {activePlans.map((plan: any, index: number) => (
                        <div 
                            key={index} 
                            className={`group relative rounded-[2.5rem] p-[1px] transition-all duration-500 hover:-translate-y-2 hover:shadow-[0_0_40px_rgba(0,168,150,0.15)] overflow-hidden`}
                        >
                            {/* Border Gradient */}
                            <div className={`absolute inset-0 bg-gradient-to-br ${plan.popular ? 'from-[#00A896] via-emerald-400 to-[#00A896]' : 'from-white/10 to-white/5'} rounded-[2.5rem] opacity-50 group-hover:opacity-100 transition-opacity`}></div>
                            
                            <div className="relative bg-[#0b0f1f] h-full rounded-[2.4rem] overflow-hidden flex flex-col">
                                {plan.popular && (
                                    <div className="absolute top-0 right-0 bg-gradient-to-l from-[#00A896] to-emerald-500 text-[#020617] text-[10px] font-black px-6 py-1.5 rounded-bl-2xl uppercase tracking-widest z-10 shadow-lg">
                                        Más Vendido
                                    </div>
                                )}
                                
                                {/* Card Header */}
                                <div className="p-8 pb-0 relative">
                                    <div className={`absolute top-0 right-0 w-32 h-32 bg-gradient-to-br ${plan.color} blur-[60px] opacity-20`}></div>
                                    <div className={`w-14 h-14 rounded-2xl flex items-center justify-center mb-6 bg-gradient-to-br ${plan.color} text-white shadow-lg`}>
                                        <plan.icon size={28} strokeWidth={1.5} />
                                    </div>
                                    <h3 className="text-2xl font-black text-white mb-2 leading-tight">{plan.title}</h3>
                                    <p className="text-xs font-medium text-slate-400 min-h-[2.5rem] leading-relaxed line-clamp-2">{plan.description}</p>
                                </div>

                                {/* Pricing & Features */}
                                <div className="p-8 pt-6 flex-1 flex flex-col justify-between">
                                    <div>
                                        <div className="flex items-end gap-2 mb-6">
                                            <span className="text-5xl font-display font-black text-white tracking-tighter">${plan.price}</span>
                                            {plan.originalPrice && (
                                                <div className="flex flex-col mb-1.5">
                                                    <span className="text-xs font-bold text-slate-500 line-through">${plan.originalPrice}</span>
                                                    <span className="text-[9px] font-black text-emerald-400 bg-emerald-400/10 px-1.5 py-0.5 rounded border border-emerald-400/20">SAVE ${plan.save}</span>
                                                </div>
                                            )}
                                        </div>

                                        <div className="space-y-4 mb-8">
                                            {plan.features.map((feat: string, i: number) => (
                                                <div key={i} className="flex items-start gap-3 text-xs font-bold text-slate-300">
                                                    <div className="min-w-[16px] mt-0.5 text-[#00A896]"><CheckCircle size={16}/></div>
                                                    <span>{feat}</span>
                                                </div>
                                            ))}
                                        </div>
                                    </div>

                                    <button 
                                        onClick={() => handleAddToCart(plan)}
                                        className={`
                                            w-full py-4 rounded-xl font-black text-sm uppercase tracking-widest flex items-center justify-center gap-3 transition-all transform active:scale-95 shadow-lg
                                            relative overflow-hidden group/btn border border-white/5
                                            ${plan.popular ? 'bg-white text-[#020617] hover:bg-[#00A896] hover:text-white' : 'bg-white/5 text-white hover:bg-white hover:text-[#020617]'}
                                        `}
                                    >
                                        <span className="relative z-10 flex items-center gap-2">
                                            <Zap size={16} fill="currentColor"/> Contratar
                                        </span>
                                    </button>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>

            {/* --- FLOATING CART BAR (MOBILE ONLY) --- */}
            {cart.length > 0 && (
                <div className="md:hidden fixed bottom-6 left-4 right-4 z-50 animate-slide-up-fade">
                    <div className="bg-[#020617]/90 text-white p-4 rounded-2xl shadow-2xl flex justify-between items-center border border-white/20 backdrop-blur-xl">
                        <div className="flex flex-col">
                            <span className="text-[10px] text-[#00A896] font-bold uppercase tracking-wider">{cart.length} Servicio{cart.length > 1 ? 's' : ''}</span>
                            <span className="text-xl font-black">${cartTotal.toFixed(2)}</span>
                        </div>
                        <button 
                            onClick={() => setIsCheckoutOpen(true)}
                            className="px-6 py-3 bg-white text-[#020617] rounded-xl text-xs font-black uppercase tracking-widest hover:scale-105 transition-transform flex items-center gap-2 shadow-lg"
                        >
                            Pagar <ArrowRight size={16}/>
                        </button>
                    </div>
                </div>
            )}

            {/* Cart Sidebar (Desktop) */}
            {isCartOpen && (
                <div className="fixed inset-0 z-[100] flex justify-end">
                    <div className="absolute inset-0 bg-black/80 backdrop-blur-sm transition-opacity" onClick={() => setIsCartOpen(false)}></div>
                    <div className="relative w-full max-w-md bg-[#0b0f1f] h-full shadow-2xl flex flex-col animate-slide-in-right border-l border-white/10">
                        <div className="p-6 bg-[#020617] text-white flex justify-between items-center shadow-lg z-10 border-b border-white/5">
                            <h3 className="text-xl font-display font-black tracking-tight flex items-center gap-2">
                                <ShoppingCart size={20} className="text-[#00A896]"/> Su Pedido
                            </h3>
                            <button onClick={() => setIsCartOpen(false)} className="p-2 hover:bg-white/10 rounded-full transition-colors"><X size={20}/></button>
                        </div>

                        <div className="flex-grow overflow-y-auto p-6 space-y-4 bg-[#0b0f1f]">
                            {cart.length === 0 ? (
                                <div className="h-full flex flex-col items-center justify-center text-slate-600 opacity-60">
                                    <Package size={64} strokeWidth={1} className="mb-4"/>
                                    <p className="font-black text-lg">Carrito Vacío</p>
                                </div>
                            ) : (
                                cart.map(item => (
                                    <div key={item.id} className="bg-white/5 p-4 rounded-2xl shadow-sm border border-white/5 flex justify-between items-center group hover:border-[#00A896]/30 transition-colors">
                                        <div>
                                            <p className="font-bold text-white text-sm mb-1">{item.title}</p>
                                            <p className="text-[#00A896] font-black text-lg">${item.price.toFixed(2)}</p>
                                        </div>
                                        <button onClick={() => removeFromCart(item.id)} className="p-2 text-slate-500 hover:text-red-400 hover:bg-red-400/10 rounded-xl transition-all">
                                            <Trash2 size={18}/>
                                        </button>
                                    </div>
                                ))
                            )}
                        </div>

                        <div className="p-6 bg-[#020617] border-t border-white/10 shadow-[0_-10px_40px_rgba(0,0,0,0.5)] z-10">
                            <div className="flex justify-between items-center mb-6">
                                <span className="text-slate-400 font-bold text-sm uppercase tracking-wider">Total a Pagar</span>
                                <span className="text-3xl font-black text-white tracking-tight">${cartTotal.toFixed(2)}</span>
                            </div>
                            <button 
                                onClick={() => { setIsCartOpen(false); setIsCheckoutOpen(true); }}
                                disabled={cart.length === 0}
                                className="w-full py-5 bg-[#00A896] text-white font-black rounded-2xl hover:bg-emerald-600 transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-teal-500/20 flex items-center justify-center gap-3 uppercase tracking-widest text-sm relative overflow-hidden group"
                            >
                                <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300"></div>
                                <span className="relative z-10 flex items-center gap-2">Confirmar Pedido <ArrowRight size={18}/></span>
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* Checkout Modal (Black Card Style) */}
            <Modal isOpen={isCheckoutOpen} onClose={() => setIsCheckoutOpen(false)} title="">
                {orderSuccess ? (
                    <div className="text-center py-12 px-6">
                        <div className="relative w-32 h-32 mx-auto mb-8">
                            <div className="absolute inset-0 bg-emerald-500 rounded-full blur-[40px] opacity-40 animate-pulse"></div>
                            <div className="relative w-full h-full bg-[#020617] border-4 border-emerald-500 rounded-full flex items-center justify-center text-emerald-500 shadow-2xl">
                                <CheckCircle size={64} />
                            </div>
                        </div>
                        <h3 className="text-3xl font-display font-black text-white mb-4">¡Bienvenido al Círculo!</h3>
                        <p className="text-slate-400 font-medium max-w-xs mx-auto leading-relaxed">Su solicitud ha sido procesada. Un asesor Elite se contactará con usted en breve.</p>
                    </div>
                ) : (
                    <div className="p-6">
                        <div className="flex justify-between items-end mb-8">
                             <div>
                                <h3 className="text-2xl font-black text-white uppercase tracking-tight">Finalizar</h3>
                                <p className="text-xs text-[#00A896] font-bold uppercase tracking-[0.2em]">Acceso Seguro</p>
                             </div>
                             <Logo className="w-10 h-10 text-white opacity-50"/>
                        </div>
                        
                        <form onSubmit={handleCheckoutSubmit} className="space-y-6">
                             {/* Black Card Container */}
                             <div className="bg-gradient-to-br from-[#1e293b] to-[#0f172a] p-6 rounded-3xl border border-white/10 shadow-2xl relative overflow-hidden">
                                 {/* Holographic Shine */}
                                 <div className="absolute top-0 left-0 w-full h-full bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-30 mix-blend-overlay"></div>
                                 <div className="absolute -top-20 -right-20 w-40 h-40 bg-[#00A896] rounded-full blur-[80px] opacity-20"></div>

                                 <div className="relative z-10 space-y-5">
                                    <div className="flex justify-between items-center border-b border-white/5 pb-4 mb-4">
                                        <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Monto Total</span>
                                        <span className="text-2xl font-mono font-bold text-white">${cartTotal.toFixed(2)}</span>
                                    </div>

                                    <div className="space-y-1">
                                        <label className="text-[9px] font-bold text-[#00A896] uppercase tracking-wider ml-1">Nombre Completo</label>
                                        <div className="relative group">
                                            <User className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-white transition-colors" size={16}/>
                                            <input required type="text" value={clientName} onChange={e => setClientName(e.target.value)} className="w-full pl-10 p-3 bg-[#020617]/50 border border-white/10 rounded-xl text-sm font-bold text-white outline-none focus:border-[#00A896] transition-all placeholder-slate-600" placeholder="NOMBRE" disabled={!!currentUser}/>
                                        </div>
                                    </div>

                                    <div className="space-y-1">
                                        <label className="text-[9px] font-bold text-[#00A896] uppercase tracking-wider ml-1">WhatsApp</label>
                                        <div className="relative group">
                                            <Phone className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-white transition-colors" size={16}/>
                                            <input required type="tel" value={clientPhone} onChange={e => setClientPhone(e.target.value)} className="w-full pl-10 p-3 bg-[#020617]/50 border border-white/10 rounded-xl text-sm font-bold text-white outline-none focus:border-[#00A896] transition-all placeholder-slate-600" placeholder="099..."/>
                                        </div>
                                    </div>

                                    <div className="space-y-1">
                                        <label className="text-[9px] font-bold text-[#00A896] uppercase tracking-wider ml-1">ID Fiscal (RUC/CI)</label>
                                        <div className="relative group">
                                            <CreditCard className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-white transition-colors" size={16}/>
                                            <input type="text" value={clientRuc} onChange={e => setClientRuc(e.target.value)} className="w-full pl-10 p-3 bg-[#020617]/50 border border-white/10 rounded-xl text-sm font-bold text-white outline-none focus:border-[#00A896] transition-all placeholder-slate-600" placeholder="OPCIONAL"/>
                                        </div>
                                    </div>
                                 </div>
                             </div>

                            <button type="submit" className="w-full py-5 bg-white text-[#020617] font-black rounded-2xl hover:bg-[#00A896] hover:text-white transition-all text-sm uppercase tracking-[0.2em] shadow-xl flex items-center justify-center gap-3 group">
                                Confirmar Acceso <Lock size={16} className="group-hover:scale-110"/>
                            </button>
                        </form>
                    </div>
                )}
            </Modal>

            {/* Simple Clean Footer */}
            <footer className="bg-[#020617] border-t border-white/5 py-12 relative z-10">
                <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-6">
                    <div className="flex items-center gap-3 opacity-50 grayscale hover:grayscale-0 hover:opacity-100 transition-all duration-500">
                        <Logo className="w-8 h-8 text-white"/>
                        <span className="font-display font-black text-white tracking-tight">SANTIAGO CORDOVA</span>
                    </div>
                    <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">
                        © 2026. Todos los derechos reservados.
                    </p>
                </div>
            </footer>
            
            <AuthModal 
                isOpen={isAuthModalOpen} 
                onClose={() => setIsAuthModalOpen(false)} 
                onLogin={(user) => {
                    onLogin(user);
                    setIsAuthModalOpen(false);
                }}
            />
        </div>
    );
};
