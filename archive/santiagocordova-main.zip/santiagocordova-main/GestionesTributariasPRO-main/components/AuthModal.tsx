
import React, { useState } from 'react';
import { Modal } from './Modal';
import { Mail, Lock, ArrowRight, CheckCircle } from 'lucide-react';
import { Logo } from './Logo';

interface AuthModalProps {
    isOpen: boolean;
    onClose: () => void;
    onLogin: (user: { name: string; email: string }) => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose, onLogin }) => {
    const [email, setEmail] = useState('');
    const [step, setStep] = useState<'initial' | 'magic-link-sent'>('initial');

    const handleGoogleLogin = () => {
        // Mock Google Login
        onLogin({
            name: 'Usuario Google',
            email: 'usuario@gmail.com'
        });
        onClose();
    };

    const handleEmailLogin = (e: React.FormEvent) => {
        e.preventDefault();
        if(email) {
            setStep('magic-link-sent');
            // In a real app, this would send a magic link. 
            // For demo, we simulate a successful login after a brief interaction or user check.
            setTimeout(() => {
                onLogin({
                    name: email.split('@')[0],
                    email: email
                });
                onClose();
                setStep('initial');
                setEmail('');
            }, 1500);
        }
    };

    return (
        <Modal isOpen={isOpen} onClose={onClose} title="">
            <div className="p-4 text-center">
                <div className="mb-6 flex justify-center">
                    <Logo className="w-16 h-16" />
                </div>
                
                {step === 'initial' ? (
                    <>
                        <h3 className="text-2xl font-display font-bold text-slate-900 dark:text-white mb-2">Bienvenido</h3>
                        <p className="text-slate-500 mb-8 text-sm">Inicia sesión para gestionar tus pedidos y servicios.</p>

                        <div className="space-y-4">
                            <button 
                                onClick={handleGoogleLogin}
                                className="w-full flex items-center justify-center space-x-3 p-3 border border-slate-300 dark:border-slate-600 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors bg-white dark:bg-slate-900 text-slate-700 dark:text-white font-medium"
                            >
                                <svg className="w-5 h-5" viewBox="0 0 24 24">
                                    <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4" />
                                    <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853" />
                                    <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.84z" fill="#FBBC05" />
                                    <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335" />
                                </svg>
                                <span>Continuar con Google</span>
                            </button>

                            <div className="flex items-center justify-between my-4">
                                <span className="w-full border-b border-slate-200 dark:border-slate-700"></span>
                                <span className="px-3 text-xs text-slate-400 uppercase">o</span>
                                <span className="w-full border-b border-slate-200 dark:border-slate-700"></span>
                            </div>

                            <form onSubmit={handleEmailLogin}>
                                <div className="relative mb-4">
                                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                                    <input 
                                        type="email" 
                                        required
                                        value={email}
                                        onChange={(e) => setEmail(e.target.value)}
                                        placeholder="tu@email.com" 
                                        className="w-full pl-10 p-3 bg-slate-100 dark:bg-slate-800 border-none rounded-xl focus:ring-2 focus:ring-gold outline-none text-slate-900 dark:text-white"
                                    />
                                </div>
                                <button type="submit" className="w-full p-3 bg-gold text-black font-bold rounded-xl hover:bg-yellow-500 transition-colors flex items-center justify-center gap-2">
                                    <span>Ingresar con Email</span>
                                    <ArrowRight size={18} />
                                </button>
                            </form>
                        </div>
                    </>
                ) : (
                    <div className="py-8 animate-fade-in-up">
                        <div className="mx-auto w-16 h-16 bg-green-100 text-green-600 rounded-full flex items-center justify-center mb-4">
                            <CheckCircle size={32} />
                        </div>
                        <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2">¡Enlace Enviado!</h3>
                        <p className="text-slate-500 text-sm">Hemos enviado un enlace de acceso mágico a <strong>{email}</strong>.</p>
                        <p className="text-xs text-slate-400 mt-4">(Simulación: Iniciando sesión automáticamente...)</p>
                    </div>
                )}
            </div>
        </Modal>
    );
};
