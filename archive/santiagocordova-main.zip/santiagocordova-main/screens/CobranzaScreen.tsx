
import React, { useMemo, useState, useRef } from 'react';
import { Client, DeclarationStatus, ReceiptData, TaxRegime, ServiceFeesConfig, ReminderConfig, BusinessProfile } from '../types';
import { getDueDateForPeriod, formatPeriodForDisplay, getPeriod, getIdentifierSortKey } from '../services/sri';
import { getClientServiceFee, addAdvancePayments } from '../services/clientService';
import { differenceInCalendarDays, isSameMonth, parseISO, isValid, subMonths, format } from 'date-fns';
import { es } from 'date-fns/locale';
import { 
    AlertTriangle, CheckCircle, MessageSquare, DollarSign, 
    Printer, Search, Loader, RefreshCw, CheckSquare, Square, Layers,
    Wallet, TrendingUp, Calendar
} from 'lucide-react';
import { useToast } from '../context/ToastContext';
import { Modal } from '../components/Modal';
import { printSalesNote } from '../services/printService';
import { PieChart, Pie, Cell, Tooltip as ReTooltip, ResponsiveContainer, Legend } from 'recharts';

interface CobranzaScreenProps {
    clients: Client[];
    setClients: React.Dispatch<React.SetStateAction<Client[]>>;
    serviceFees: ServiceFeesConfig;
    reminderConfig: ReminderConfig;
}

interface FinancialItem {
    clientId: string;
    clientName: string;
    ruc: string;
    period: string;
    amount: number;
    status: DeclarationStatus;
    type: 'mensual' | 'semestral' | 'renta' | 'dev';
    dateReference: Date; 
    daysDiff?: number;
    phones: string[];
    isVirtual?: boolean; 
}

const defaultBusinessProfile: BusinessProfile = {
    ruc: '0700000000001',
    businessName: 'Santiago Cordova',
    tradeName: 'Soluciones Tributarias',
    address: 'Colon y Sucre / Pasaje - El Oro',
    phone: '+593 978 980 722',
    email: 'info@santiagocordova.com',
    authNumber: '0000000000'
};

export const CobranzaScreen: React.FC<CobranzaScreenProps> = ({ clients, setClients, serviceFees }) => {
    const { toast } = useToast();
    const [activeTab, setActiveTab] = useState<'receivable' | 'projected' | 'collected'>('receivable');
    const [searchTerm, setSearchTerm] = useState('');
    const [isRecalculating, setIsRecalculating] = useState(false);
    const [selectedItems, setSelectedItems] = useState<Set<string>>(new Set()); 
    const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
    
    // States for Advance Payment (Adelantos)
    const [isAdvanceModalOpen, setIsAdvanceModalOpen] = useState(false);
    const [advanceClientId, setAdvanceClientId] = useState<string>('');
    const [advanceMonths, setAdvanceMonths] = useState<number>(1);
    const [includeRenta, setIncludeRenta] = useState(false);

    const [isProcessing, setIsProcessing] = useState(false);
    const [receiptData, setReceiptData] = useState<ReceiptData | null>(null);
    const [isReceiptOpen, setIsReceiptOpen] = useState(false);
    
    // Referencia para impresión
    const receiptRef = useRef<HTMLDivElement>(null);

    const financialData = useMemo(() => {
        const receivable: FinancialItem[] = [];
        const projected: FinancialItem[] = [];
        const collected: FinancialItem[] = [];
        const now = new Date();
        const selectedMonth = new Date(); 

        clients.forEach(client => {
            if (client.isDeleted || client.isActive === false) return;
            let fee = getClientServiceFee(client, serviceFees);
            if (fee <= 0) fee = 10.00;

            let type: FinancialItem['type'] = 'mensual';
            if (client.category.includes('Semestral')) type = 'semestral';
            else if (client.regime === TaxRegime.RimpeNegocioPopular) type = 'renta';
            else if (client.category.includes('Devolución')) type = 'dev';

            const processedPeriods = new Set<string>();

            client.declarationHistory.forEach(decl => {
                processedPeriods.add(decl.period);
                if (decl.status === DeclarationStatus.Pagada && decl.paidAt) {
                    const paidDate = parseISO(decl.paidAt);
                    if (isValid(paidDate) && isSameMonth(paidDate, selectedMonth)) {
                        collected.push({
                            clientId: client.id, clientName: client.name, ruc: client.ruc,
                            period: decl.period, amount: decl.amount || fee, status: DeclarationStatus.Pagada,
                            type, dateReference: paidDate, phones: client.phones || []
                        });
                    }
                } else if (decl.status === DeclarationStatus.Enviada || decl.status === DeclarationStatus.Pendiente) {
                    const dueDate = getDueDateForPeriod(client, decl.period) || now;
                    receivable.push({
                        clientId: client.id, clientName: client.name, ruc: client.ruc,
                        period: decl.period, amount: decl.amount || fee, status: decl.status,
                        type, dateReference: dueDate, daysDiff: differenceInCalendarDays(now, dueDate),
                        phones: client.phones || []
                    });
                }
            });
            
            const pNow = getPeriod(client, now);
            const pPrev = getPeriod(client, subMonths(now, 1));
            [pNow, pPrev].forEach(p => {
                if (!processedPeriods.has(p)) {
                    const dueDate = getDueDateForPeriod(client, p) || now;
                    const diff = differenceInCalendarDays(now, dueDate);
                    const item: FinancialItem = {
                        clientId: client.id, clientName: client.name, ruc: client.ruc,
                        period: p, amount: fee, status: DeclarationStatus.Pendiente, 
                        type, dateReference: dueDate, daysDiff: diff, phones: client.phones || [], isVirtual: true 
                    };
                    if (diff > 0) receivable.push(item);
                    else projected.push(item);
                }
            });
        });
        return { receivable, projected, collected };
    }, [clients, serviceFees, isRecalculating]);

    const currentList = useMemo(() => {
        let list = activeTab === 'receivable' ? financialData.receivable 
                 : activeTab === 'projected' ? financialData.projected 
                 : financialData.collected;
        if (searchTerm) {
            const lower = searchTerm.toLowerCase();
            list = list.filter(i => i.clientName.toLowerCase().includes(lower) || i.ruc.includes(lower));
        }
        return list;
    }, [financialData, activeTab, searchTerm]);

    const chartData = [
        { name: 'Cobrable', value: financialData.receivable.reduce((s,i) => s+i.amount, 0), color: '#ef4444' },
        { name: 'Recaudado', value: financialData.collected.reduce((s,i) => s+i.amount, 0), color: '#10b981' }
    ].filter(d => d.value > 0);

    const sortedClients = useMemo(() => {
        return [...clients].sort((a,b) => getIdentifierSortKey(a.ruc) - getIdentifierSortKey(b.ruc));
    }, [clients]);

    const selectedAdvanceClient = useMemo(() => {
        return clients.find(c => c.id === advanceClientId);
    }, [clients, advanceClientId]);

    const advancePaymentSummary = useMemo(() => {
        if (!selectedAdvanceClient) return { total: 0, count: 0 };
        const fee = getClientServiceFee(selectedAdvanceClient, serviceFees);
        let total = fee * advanceMonths;
        if (includeRenta && selectedAdvanceClient.regime !== TaxRegime.RimpeNegocioPopular) {
            total += serviceFees.rentaGeneral;
        }
        return { total, count: advanceMonths };
    }, [selectedAdvanceClient, advanceMonths, includeRenta, serviceFees]);

    const handleProcessPayment = () => {
        if (selectedItems.size === 0) return;
        setIsProcessing(true);
        const nowIso = new Date().toISOString();
        const transactionId = `PAY-${Date.now().toString().slice(-6)}`;
        const newClients = [...clients];
        let lastClient;
        let paidPeriods: any[] = [];

        selectedItems.forEach(key => {
            const item = currentList.find(i => `${i.clientId}-${i.period}` === key);
            if (!item) return;
            const clientIdx = newClients.findIndex(c => c.id === item.clientId);
            if (clientIdx === -1) return;
            const history = [...newClients[clientIdx].declarationHistory];
            const declIdx = history.findIndex(d => d.period === item.period);
            const entry = { period: item.period, status: DeclarationStatus.Pagada, paidAt: nowIso, transactionId, amount: item.amount, updatedAt: nowIso };
            if (declIdx > -1) history[declIdx] = { ...history[declIdx], ...entry };
            else history.push(entry as any);
            newClients[clientIdx] = { ...newClients[clientIdx], declarationHistory: history };
            lastClient = newClients[clientIdx];
            paidPeriods.push({ period: item.period, amount: item.amount });
        });

        setTimeout(() => {
            setClients(newClients);
            setIsProcessing(false);
            setIsPaymentModalOpen(false);
            setSelectedItems(new Set());
            if (lastClient) setReceiptData({ transactionId, clientName: lastClient.name, clientRuc: lastClient.ruc, client: lastClient, paymentDate: format(new Date(), 'PPpp', { locale: es }), paidPeriods, totalAmount: paidPeriods.reduce((s,p) => s+p.amount, 0) });
            setIsReceiptOpen(true);
            toast.success("Pago registrado");
        }, 800);
    };

    const handleProcessAdvance = () => {
        if (!selectedAdvanceClient || advanceMonths < 1) return;
        setIsProcessing(true);

        setTimeout(() => {
            const result = addAdvancePayments(selectedAdvanceClient, advanceMonths, serviceFees, includeRenta);
            
            // Actualizar cliente
            setClients(prev => prev.map(c => c.id === result.updatedClient.id ? result.updatedClient : c));
            
            // Preparar Recibo
            setReceiptData({
                transactionId: result.transactionId,
                clientName: selectedAdvanceClient.name,
                clientRuc: selectedAdvanceClient.ruc,
                client: selectedAdvanceClient,
                paymentDate: format(new Date(), 'PPpp', { locale: es }),
                paidPeriods: result.paidPeriods,
                totalAmount: result.paidPeriods.reduce((sum, p) => sum + p.amount, 0)
            });

            setIsProcessing(false);
            setIsAdvanceModalOpen(false);
            setIsReceiptOpen(true);
            
            // Reset
            setAdvanceClientId('');
            setAdvanceMonths(1);
            setIncludeRenta(false);
            toast.success("Adelanto registrado correctamente");
        }, 800);
    };

    return (
        <div className="space-y-6 pb-20 animate-fade-in">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
                <div>
                    <h2 className="text-3xl font-display font-black text-[#0B2149] dark:text-white">Gestiones Tributarias - Santiago Cordova</h2>
                    <p className="text-slate-500 text-sm mt-1">Control de ingresos y cuentas pendientes.</p>
                </div>
                <div className="flex gap-4 w-full md:w-auto">
                    <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border-l-4 border-red-500 shadow-sm flex-1 min-w-[140px]">
                        <p className="text-[10px] font-bold text-slate-400 uppercase mb-1">Por Cobrar</p>
                        <p className="text-xl font-black text-red-600">${financialData.receivable.reduce((s,i) => s+i.amount, 0).toFixed(2)}</p>
                    </div>
                    <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border-l-4 border-emerald-500 shadow-sm flex-1 min-w-[140px]">
                        <p className="text-[10px] font-bold text-slate-400 uppercase mb-1">Recaudado (Mes)</p>
                        <p className="text-xl font-black text-emerald-600">${financialData.collected.reduce((s,i) => s+i.amount, 0).toFixed(2)}</p>
                    </div>
                </div>
            </div>

            <div className="bg-white dark:bg-slate-900 p-2 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-800 flex flex-col lg:flex-row gap-4 items-center">
                <div className="flex p-1 bg-slate-100 dark:bg-slate-800 rounded-xl w-full lg:w-auto overflow-x-auto">
                    {(['receivable', 'projected', 'collected'] as const).map(tab => (
                        <button key={tab} onClick={() => setActiveTab(tab)} className={`flex-1 lg:flex-none px-6 py-2 rounded-lg text-xs font-bold transition-all whitespace-nowrap ${activeTab === tab ? 'bg-white dark:bg-slate-700 shadow-sm' : 'text-slate-500'}`}>
                            {tab === 'receivable' ? 'Por Cobrar' : tab === 'projected' ? 'Proyección' : 'Ingresos'}
                        </button>
                    ))}
                </div>
                <div className="relative flex-grow w-full">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                    <input type="text" placeholder="Buscar cliente..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} className="w-full pl-10 pr-4 py-2 bg-slate-50 dark:bg-slate-800 border-none rounded-xl text-sm" />
                </div>
                <div className="flex gap-2 w-full sm:w-auto">
                    <button 
                        onClick={() => setIsAdvanceModalOpen(true)}
                        className="flex-1 sm:flex-none px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-colors shadow-sm whitespace-nowrap"
                    >
                        <Wallet size={16}/> Registrar Adelanto
                    </button>
                    <button onClick={() => setIsRecalculating(p => !p)} className="p-2 text-slate-400 hover:text-brand-teal transition-colors"><RefreshCw size={20}/></button>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
                <div className="lg:col-span-1 bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-100 dark:border-slate-800 h-fit">
                    <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-4">Estado de Cartera</h3>
                    <div className="h-48 w-full">
                        <ResponsiveContainer width="100%" height="100%">
                            <PieChart>
                                <Pie data={chartData} cx="50%" cy="50%" innerRadius={40} outerRadius={60} paddingAngle={5} dataKey="value">
                                    {chartData.map((entry, index) => <Cell key={index} fill={entry.color} />)}
                                </Pie>
                                <ReTooltip />
                                <Legend wrapperStyle={{ fontSize: '10px' }} />
                            </PieChart>
                        </ResponsiveContainer>
                    </div>
                    {selectedItems.size > 0 && (
                        <button onClick={() => setIsPaymentModalOpen(true)} className="w-full mt-6 py-3 bg-[#0B2149] text-white rounded-xl font-bold text-sm shadow-lg flex items-center justify-center gap-2">
                            <DollarSign size={16}/> Cobrar Seleccionados ({selectedItems.size})
                        </button>
                    )}
                </div>

                <div className="lg:col-span-3 bg-white dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-800 overflow-hidden">
                    <div className="p-4 bg-slate-50 dark:bg-slate-950/50 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center">
                        <button onClick={() => {
                            if (selectedItems.size === currentList.length) setSelectedItems(new Set());
                            else setSelectedItems(new Set(currentList.map(i => `${i.clientId}-${i.period}`)));
                        }} className="flex items-center gap-2 text-xs font-bold text-slate-500">
                            {selectedItems.size === currentList.length ? <CheckSquare size={16}/> : <Square size={16}/>}
                            Seleccionar Todos
                        </button>
                        <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">{currentList.length} Registros</span>
                    </div>
                    <div className="divide-y divide-slate-100 dark:divide-slate-800 max-h-[600px] overflow-y-auto">
                        {currentList.map(item => {
                            const key = `${item.clientId}-${item.period}`;
                            const isSelected = selectedItems.has(key);
                            return (
                                <div key={key} onClick={() => activeTab !== 'collected' && (isSelected ? setSelectedItems(s => {const n=new Set(s);n.delete(key);return n;}) : setSelectedItems(s => new Set(s).add(key)))} className={`p-4 flex items-center justify-between hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors cursor-pointer ${isSelected ? 'bg-blue-50 dark:bg-blue-900/10' : ''}`}>
                                    <div className="flex items-center gap-4">
                                        <div className={`p-2 rounded-xl ${item.type === 'mensual' ? 'bg-blue-50 text-blue-500' : 'bg-purple-50 text-purple-500'}`}>
                                            <Layers size={18}/>
                                        </div>
                                        <div>
                                            <p className="font-bold text-sm text-slate-800 dark:text-white">{item.clientName}</p>
                                            <p className="text-[10px] text-slate-400 font-mono">{formatPeriodForDisplay(item.period)} • {item.ruc}</p>
                                        </div>
                                    </div>
                                    <div className="text-right">
                                        <p className="font-black text-sm text-slate-900 dark:text-white">${item.amount.toFixed(2)}</p>
                                        <p className={`text-[9px] font-bold uppercase tracking-widest ${item.daysDiff && item.daysDiff > 0 ? 'text-red-500' : 'text-slate-400'}`}>
                                            {item.status === 'Pagada' ? 'Pagado' : item.daysDiff && item.daysDiff > 0 ? `Vencido hace ${item.daysDiff}d` : 'Por vencer'}
                                        </p>
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                </div>
            </div>

            {/* MODAL COBRO NORMAL */}
            <Modal isOpen={isPaymentModalOpen} onClose={() => setIsPaymentModalOpen(false)} title="Confirmar Cobro">
                <div className="p-4 space-y-6">
                    <div className="bg-slate-50 dark:bg-slate-800 p-6 rounded-2xl text-center">
                        <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">Total a Recaudar</p>
                        <p className="text-4xl font-black text-[#0B2149] dark:text-white">
                            ${Array.from(selectedItems).reduce<number>((sum, key) => sum + (currentList.find(i => `${i.clientId}-${i.period}` === key)?.amount || 0), 0).toFixed(2)}
                        </p>
                    </div>
                    <button onClick={handleProcessPayment} disabled={isProcessing} className="w-full py-4 bg-emerald-600 text-white rounded-xl font-bold flex items-center justify-center gap-2 shadow-lg">
                        {isProcessing ? <RefreshCw className="animate-spin" size={20}/> : <CheckCircle size={20}/>}
                        Confirmar Transacción
                    </button>
                </div>
            </Modal>

            {/* MODAL ADELANTO (ABONO) */}
            <Modal isOpen={isAdvanceModalOpen} onClose={() => setIsAdvanceModalOpen(false)} title="Registrar Adelanto / Abono">
                <div className="space-y-6">
                    <div>
                        <label className="text-xs font-bold text-slate-500 uppercase mb-2 block">Cliente</label>
                        <select 
                            value={advanceClientId} 
                            onChange={(e) => setAdvanceClientId(e.target.value)}
                            className="w-full p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl outline-none focus:ring-2 focus:ring-blue-500"
                        >
                            <option value="">Seleccione un cliente...</option>
                            {sortedClients.filter(c => c.isActive !== false).map(c => (
                                <option key={c.id} value={c.id}>{c.name}</option>
                            ))}
                        </select>
                    </div>

                    {selectedAdvanceClient && (
                        <div className="animate-fade-in-up space-y-4">
                            <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-xl border border-blue-100 dark:border-blue-800">
                                <div className="flex justify-between items-center mb-2">
                                    <span className="text-xs font-bold text-blue-600 dark:text-blue-400 uppercase">Tarifa Actual</span>
                                    <span className="text-lg font-black text-blue-800 dark:text-blue-300">
                                        ${getClientServiceFee(selectedAdvanceClient, serviceFees).toFixed(2)}
                                    </span>
                                </div>
                                <p className="text-xs text-blue-500/80">
                                    {selectedAdvanceClient.category} • {selectedAdvanceClient.regime}
                                </p>
                            </div>

                            <div>
                                <label className="text-xs font-bold text-slate-500 uppercase mb-2 block">
                                    Periodos a Adelantar ({selectedAdvanceClient.category.includes('Semestral') ? 'Semestres' : 'Meses'})
                                </label>
                                <div className="flex items-center gap-4">
                                    <input 
                                        type="range" min="1" max="12" 
                                        value={advanceMonths} 
                                        onChange={(e) => setAdvanceMonths(parseInt(e.target.value))}
                                        className="flex-grow h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
                                    />
                                    <span className="w-12 text-center font-bold text-xl text-slate-700 dark:text-white">{advanceMonths}</span>
                                </div>
                            </div>

                            {selectedAdvanceClient.regime !== TaxRegime.RimpeNegocioPopular && (
                                <div className="flex items-center gap-3 p-3 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 cursor-pointer" onClick={() => setIncludeRenta(!includeRenta)}>
                                    <div className={`w-5 h-5 rounded border flex items-center justify-center transition-colors ${includeRenta ? 'bg-blue-600 border-blue-600' : 'border-slate-400'}`}>
                                        {includeRenta && <CheckCircle size={14} className="text-white"/>}
                                    </div>
                                    <span className="text-sm font-medium text-slate-700 dark:text-slate-300">Incluir Renta Anual (+${serviceFees.rentaGeneral})</span>
                                </div>
                            )}

                            <div className="pt-4 border-t border-slate-100 dark:border-slate-800">
                                <div className="flex justify-between items-end mb-6">
                                    <div>
                                        <p className="text-xs text-slate-400 font-bold uppercase">Total a Pagar</p>
                                        <p className="text-xs text-slate-400">
                                            {advanceMonths} {selectedAdvanceClient.category.includes('Semestral') ? 'Semestres' : 'Meses'} {includeRenta ? '+ Renta' : ''}
                                        </p>
                                    </div>
                                    <p className="text-4xl font-black text-emerald-600">${advancePaymentSummary.total.toFixed(2)}</p>
                                </div>

                                <button 
                                    onClick={handleProcessAdvance} 
                                    disabled={isProcessing}
                                    className="w-full py-4 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold flex items-center justify-center gap-2 shadow-lg transition-all"
                                >
                                    {isProcessing ? <RefreshCw className="animate-spin" size={20}/> : <Wallet size={20}/>}
                                    Registrar Adelanto
                                </button>
                            </div>
                        </div>
                    )}
                </div>
            </Modal>

            {/* RECIBO */}
            <Modal isOpen={isReceiptOpen} onClose={() => setIsReceiptOpen(false)} title="Comprobante de Venta">
                {receiptData && (
                    <div className="p-4">
                        <div ref={receiptRef} className="bg-white p-6 rounded-xl border border-slate-200 text-slate-800 font-mono text-xs">
                            <div className="text-center mb-6">
                                <p className="font-bold text-lg uppercase">{defaultBusinessProfile.businessName}</p>
                                <p>{defaultBusinessProfile.address}</p>
                                <p>RUC: {defaultBusinessProfile.ruc}</p>
                                <p className="mt-4 border-b border-dashed pb-2 font-bold uppercase">Nota de Venta No. {receiptData.transactionId}</p>
                            </div>
                            <div className="space-y-1 mb-6">
                                <p>CLIENTE: {receiptData.clientName}</p>
                                <p>RUC/CI: {receiptData.clientRuc}</p>
                                <p>FECHA: {receiptData.paymentDate}</p>
                            </div>
                            <table className="w-full mb-6">
                                <thead className="border-b border-dashed">
                                    <tr><th className="text-left py-2">DESCRIPCION</th><th className="text-right py-2">TOTAL</th></tr>
                                </thead>
                                <tbody>
                                    {receiptData.paidPeriods.map((p,i) => <tr key={i}><td className="py-2">HONORARIOS PROF. {p.period}</td><td className="text-right">${p.amount.toFixed(2)}</td></tr>)}
                                </tbody>
                            </table>
                            <div className="text-right font-bold text-sm border-t border-dashed pt-2">
                                TOTAL: ${receiptData.totalAmount.toFixed(2)}
                            </div>
                        </div>
                        <div className="mt-6 flex gap-3">
                            <button onClick={() => printSalesNote(receiptData, defaultBusinessProfile)} className="flex-1 py-3 bg-slate-900 text-white rounded-xl font-bold flex items-center justify-center gap-2"><Printer size={18}/> Imprimir</button>
                            <button onClick={() => setIsReceiptOpen(false)} className="flex-1 py-3 bg-slate-100 text-slate-600 rounded-xl font-bold">Cerrar</button>
                        </div>
                    </div>
                )}
            </Modal>
        </div>
    );
};
