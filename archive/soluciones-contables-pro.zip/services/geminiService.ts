
import { GoogleGenAI, Type } from "@google/genai";
import { Client, Task, AnalysisType } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const summarizeTextWithGemini = async (text: string): Promise<string> => {
  if (!text) return "";
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `Resume este texto de manera concisa (máximo 2 oraciones) para un perfil de cliente contable:\n\n${text}`,
    });
    return response.text || "";
  } catch (error) {
    console.error("Error summarizing:", error);
    return "No se pudo generar el resumen.";
  }
};

export const analyzeClientPhoto = async (base64Image: string, mimeType: string): Promise<Partial<Client> & { phone?: string }> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: {
        parts: [
          { inlineData: { mimeType, data: base64Image } },
          { text: "Analiza esta imagen de documento (Cédula o RUC de Ecuador). Extrae los datos en JSON: ruc, name (razón social o nombre), sriPassword (si es visible), regime (General, RIMPE Negocio Popular, RIMPE Emprendedor), category (categoría probable), phone, email, notes (dirección u otros detalles)." }
        ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            ruc: { type: Type.STRING },
            name: { type: Type.STRING },
            sriPassword: { type: Type.STRING },
            regime: { type: Type.STRING, enum: ["Régimen General", "RIMPE Negocio Popular", "RIMPE Emprendedor"] },
            category: { type: Type.STRING },
            phone: { type: Type.STRING },
            email: { type: Type.STRING },
            notes: { type: Type.STRING },
          }
        }
      }
    });
    
    const text = response.text;
    return text ? JSON.parse(text) : {};
  } catch (error) {
    console.error("Error analyzing photo:", error);
    throw new Error("No se pudo analizar la imagen.");
  }
};

export const runStrategicAnalysis = async (clients: Client[], tasks: Task[], type: AnalysisType): Promise<string> => {
    const clientsSummary = clients.map(c => ({ name: c.name, regime: c.regime, debt: c.declarationHistory.filter(d => d.status !== 'Pagada').length }));
    const tasksSummary = tasks.filter(t => t.status !== 'Completada').map(t => ({ title: t.title, cost: t.cost }));

    let prompt = "";
    switch(type) {
        case 'cashflow': prompt = "Analiza el flujo de caja y deudas. Formato HTML simple con <h3>, <p>, <ul>."; break;
        case 'riskMatrix': prompt = "Genera una matriz de riesgo de clientes. Formato HTML simple."; break;
        case 'optimization': prompt = "Sugiere optimización de servicios. Formato HTML simple."; break;
        case 'efficiency': prompt = "Analiza la eficiencia operativa. Formato HTML simple."; break;
    }

    try {
         const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: `Contexto: Soy contador. Datos Clientes: ${JSON.stringify(clientsSummary)}. Tareas: ${JSON.stringify(tasksSummary)}. \n\nTarea: ${prompt}`,
        });
        return response.text || "No se pudo generar el análisis.";
    } catch (error) {
        console.error(error);
        return "<p>Error al generar el análisis estratégico.</p>";
    }
};
