export type Screen = 'home' | 'clients' | 'tasks' | 'reports' | 'settings' | 'cobranza' | 'calendar';
export type Theme = 'light' | 'dark' | 'midnight';

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
}

export enum DeclarationStatus {
  Pendiente = 'Pendiente',
  Enviada = 'Enviada',
  Pagada = 'Pagada',
  Cancelada = 'Cancelada',
}

export enum TaxRegime {
  General = 'Régimen General',
  RimpeNegocioPopular = 'RIMPE Negocio Popular',
  RimpeEmprendedor = 'RIMPE Emprendedor',
}

export enum ClientCategory {
  SuscripcionMensual = 'Suscripción Mensual IVA',
  InternoMensual = 'Interno Mensual',
  SuscripcionSemestral = 'Suscripción Semestral',
  InternoSemestral = 'Interno Semestral',
  ImpuestoRentaNegocioPopular = 'Impuesto a la Renta (Negocio Popular)',
  DevolucionIvaTerceraEdad = 'Devolución IVA 3ra Edad (Mensual)',
}

export enum RentaCategory {
  Suscripcion = 'Suscripción Renta',
  Interno = 'Interno Renta',
}

export interface ServiceFeesConfig {
  ivaMensual: number;
  ivaSemestral: number;
  rentaNP: number;
  rentaGeneral: number;
  devolucionIva: number;
  devolucionRenta: number;
  anexoGastosPersonales: number;
  customPunctualServices?: Array<{ id: string; name: string; price: number }>;
}

export interface ReminderConfig {
  isEnabled: boolean;
  daysBefore: number;
  onDueDate: boolean;
  overdueInterval: number;
  template: string;
}

export type ReminderType = 'upcoming' | 'due_date' | 'overdue';

export interface Declaration {
  period: string; // e.g., '2024-07', '2024-S1', or '2024'
  status: DeclarationStatus;
  updatedAt: string; // ISO string
  declaredAt?: string; // ISO string for when it was marked 'Enviada'
  paidAt?: string; // ISO string for when it was marked 'Pagada'
  transactionId?: string; // For advance payment receipts
  amount?: number; // Fee paid for this period
  reminders?: Array<{ date: string; channel: 'email' | 'whatsapp', type: ReminderType }>;
}

export interface Client {
  id: string;
  ruc: string;
  name: string;
  sriPassword: string;
  phones?: string[];
  email?: string;
  notes?: string;
  regime: TaxRegime;
  category: ClientCategory;
  rentaCategory?: RentaCategory;
  declarationHistory: Declaration[];
  isDeleted?: boolean;
  isActive?: boolean;
  customServiceFee?: number;
  annualRentaStatus?: DeclarationStatus;
}

export enum TaskStatus {
  Pendiente = 'Pendiente',
  EnProceso = 'En Proceso',
  Completada = 'Completada',
  Abono = 'Abono',
  Pagada = 'Pagada',
}

export interface Task {
  id: string;
  title: string;
  description: string;
  clientId?: string;
  nonClientName?: string;
  nonClientRuc?: string;
  sriPassword?: string;
  dueDate: string; // ISO string
  status: TaskStatus;
  attachments?: File[];
  cost?: number;
  advancePayment?: number;
}

export type ClientFilter = { 
  category?: ClientCategory; 
  regimes?: TaxRegime[]; 
  title?: string 
};

export type TranscribableField = 'ruc' | 'name' | 'sriPassword' | 'email' | 'phone' | 'notes';

export type AnalysisType = 'cashflow' | 'riskMatrix' | 'optimization' | 'efficiency';

export interface AdvancePaymentResult {
    updatedClient: Client;
    paidPeriods: { period: string; amount: number }[];
    transactionId: string;
    newRentaTask?: Task;
}