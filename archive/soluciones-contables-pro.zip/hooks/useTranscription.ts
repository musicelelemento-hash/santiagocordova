
import { useState, useRef, useCallback } from 'react';
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export function useTranscription() {
    const [isRecording, setIsRecording] = useState(false);
    const [transcribingField, setTranscribingField] = useState<string | null>(null);
    const [transcription, setTranscription] = useState('');
    const [error, setError] = useState<string | null>(null);
    const mediaRecorderRef = useRef<MediaRecorder | null>(null);
    const audioChunksRef = useRef<Blob[]>([]);

    const startTranscription = useCallback(async (field: string) => {
        setTranscribingField(field);
        setTranscription('');
        setError(null);
        audioChunksRef.current = [];
        
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            const mediaRecorder = new MediaRecorder(stream);
            mediaRecorderRef.current = mediaRecorder;
            
            mediaRecorder.ondataavailable = (event) => {
                if (event.data.size > 0) audioChunksRef.current.push(event.data);
            };
            
            mediaRecorder.start();
            setIsRecording(true);
        } catch (err) {
            console.error(err);
            setError("Error al acceder al micrófono");
            setIsRecording(false);
            setTranscribingField(null);
        }
    }, []);

    const stopTranscription = useCallback(async () => {
        if (!mediaRecorderRef.current) return;
        
        return new Promise<void>(resolve => {
            mediaRecorderRef.current!.onstop = async () => {
                const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
                const reader = new FileReader();
                reader.readAsDataURL(audioBlob);
                reader.onloadend = async () => {
                    const base64Audio = (reader.result as string).split(',')[1];
                    try {
                         const response = await ai.models.generateContent({
                            model: 'gemini-2.5-flash',
                            contents: {
                                parts: [
                                    { inlineData: { mimeType: 'audio/webm', data: base64Audio } },
                                    { text: "Transcribe lo siguiente en español textualmente:" }
                                ]
                            }
                        });
                        setTranscription(response.text || '');
                    } catch (err) {
                        console.error(err);
                        setError("Error en la transcripción");
                    } finally {
                        setIsRecording(false);
                        setTranscribingField(null);
                        if (mediaRecorderRef.current) {
                            mediaRecorderRef.current.stream.getTracks().forEach(t => t.stop());
                            mediaRecorderRef.current = null;
                        }
                        resolve();
                    }
                };
            };
            mediaRecorderRef.current!.stop();
        });
    }, []);

    return { isRecording, transcribingField, transcription, error, startTranscription, stopTranscription };
}
