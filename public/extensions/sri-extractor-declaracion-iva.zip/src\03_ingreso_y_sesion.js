SafeStorage.get(null).then(async (items) => {
    // Antes que nada: si hay credenciales de Supabase en Ajustes, mandan ellas.
    // Va acá porque es el primer volcado completo del storage y todo lo que
    // habla con la web pasa mucho después.
    if (typeof aplicarCredencialesSupabaseGuardadas === 'function') {
        aplicarCredencialesSupabaseGuardadas(items);
    }

    // ── El cortacircuitos de verdad ───────────────────────────────────────
    //
    // El AGENTS.md §2 promete que `actionTimestamp` previene los bucles
    // infinitos porque «toda acción tiene una fecha de caducidad». Esa promesa
    // NO se cumplía: el timestamp se reescribe con `Date.now()` en treinta y
    // dos lugares, y la caducidad se medía contra ese valor renovado. El
    // propio bucle renovaba su propio plazo, así que un bucle rápido no vencía
    // nunca.
    //
    // Contar tiempo no sirve. Se cuentan RECARGAS: una acción que trabaja
    // dentro de una sola página no recarga; un bucle recarga siempre. Si la
    // misma acción sobrevive a ocho cargas seguidas, es un bucle — y no hay
    // ningún caso legítimo que se parezca a eso.
    //
    // Lo contó el usuario el 07-sep-2026 con una clienta: «se quedaba en bucle
    // al querer marcar declaraciones de IVA, y luego cerré y abrí y siempre
    // así esa ejecución con ese cliente». «Siempre así» es lo que este bloque
    // corta: la acción quedaba pegada en el almacén sin forma de rendirse.
    // Una acción que NO es de quien está en curso no se ejecuta.
    //
    // El 07-sep-2026 el cliente 1 de un lote arrancó con la acción del
    // contribuyente anterior: se apretó ▶ mientras la extracción de ése seguía
    // en vuelo, y al terminar pisó la acción recién preparada. Ejecutar el paso
    // de otro es buscar comprobantes del mes equivocado en la sesión de otro.
    if (items.pendingAction && items.accionDeQuien &&
        items.pending_sri_autofill?.ruc &&
        items.accionDeQuien !== items.pending_sri_autofill.ruc) {
        console.warn(`🏷️ [ACCIÓN] «${items.pendingAction}» era de ${items.accionDeQuien} y ahora ` +
                     `está en curso ${items.pending_sri_autofill.ruc}. Se descarta: la acción de ` +
                     'un contribuyente no se ejecuta sobre otro.');
        await SafeStorage.remove(['pendingAction', 'actionTimestamp', 'accionDeQuien',
                                  'accionEnCurso', 'accionVueltas', 'recuperarComprobante']);
        items.pendingAction = null;
    }

    const TOPE_DE_VUELTAS = 8;
    if (items.pendingAction) {
        const mismaQueAntes = items.accionEnCurso === items.pendingAction;
        const vueltas = mismaQueAntes ? (items.accionVueltas || 0) + 1 : 1;

        if (vueltas > TOPE_DE_VUELTAS) {
            console.error(`🔁 [BUCLE] La acción «${items.pendingAction}» lleva ${vueltas} cargas de ` +
                          'página sin terminar. Eso es un bucle: se descarta y el navegador queda libre.');
            console.error('   Si esto se repite con el mismo contribuyente, el paso que se traba es ése ' +
                          'y hay que mirarlo — no es un problema de su clave.');
            await anotarBitacora('🔁 bucle cortado', `${items.pendingAction} · ${vueltas} cargas`);
            await SafeStorage.remove(['pendingAction', 'actionTimestamp', 'accionEnCurso',
                                      'accionVueltas', 'recuperarComprobante', 'bajarTodos']);
            if (window.sriAssistant?.showEliteToast) {
                window.sriAssistant.showEliteToast({
                    title: '🔁 Bucle cortado',
                    msg: `«${items.pendingAction}» daba vueltas sin avanzar. Se descartó para liberar la página.`,
                    duration: 9000
                });
            }
            items.pendingAction = null;
        } else {
            await SafeStorage.set({ accionEnCurso: items.pendingAction, accionVueltas: vueltas });
            // A la mitad se avisa, para que se vea venir en el log en vez de
            // descubrirlo cuando ya se cortó.
            if (vueltas === Math.ceil(TOPE_DE_VUELTAS / 2)) {
                console.warn(`🔁 [BUCLE] «${items.pendingAction}» va por la vuelta ${vueltas} de ` +
                             `${TOPE_DE_VUELTAS}. Si llega al tope se descarta.`);
            }
        }
    } else if (items.accionEnCurso) {
        // No hay acción pendiente: el contador vuelve a cero solo.
        await SafeStorage.remove(['accionEnCurso', 'accionVueltas']);
    }

    const isLoginPage = isSRILoginPage();

    // ── Radiografía de arranque ────────────────────────────────────────────
    try {
        const sem = await SriLoop.get();
        const af = items.pending_sri_autofill;
        const total = (sem.cola || []).length;
        console.log(
            `🚦 [ESTADO] semáforo=${sem.estado}` +
            `${total ? ` · cliente ${sem.indice + 1}/${total}` : ' · sin lote'}` +
            ` · autofill=${af ? `${af.name || af.ruc} [${[af.manual && 'manual', af.isBatch && 'lote', af.loginAttempted && 'login-hecho'].filter(Boolean).join(',') || 'sin banderas'}]` : 'no'}` +
            ` · acción=${items.pendingAction || '—'}` +
            ` · login=${isLoginPage ? 'sí' : 'no'}` +
            `${sem.motivo ? ' · ' + sem.motivo : ''}`
        );
        // Solo se anota si hay lote o credenciales en juego: en navegación
        // suelta del usuario la bitácora no tiene nada que explicar.
        if (sem.estado !== 'DETENIDO' || af) {
            await anotarBitacora('carga página',
                `${location.pathname.split('/').pop() || '/'} · login=${isLoginPage ? 'sí' : 'no'} · autofill=${af ? (af.name || af.ruc) : 'no'}`);
        }
    } catch (e) { /* no romper el arranque por un log */ }

    if (window.location.href.includes('pagina-no-encontrada')) {
        console.warn('⚠️ [404 SRI] Página no encontrada detectada en Angular. Redirigiendo limpiamente a inicio/NAT...');
        window.location.href = 'https://srienlinea.sri.gob.ec/sri-en-linea/inicio/NAT';
        return;
    }

    if (window.location.href.includes('salirSSO.jsp')) {
        console.log('🚪 [SALIR SSO] Redirección detectada en salirSSO.jsp. Continuando hacia el portal...');
        setTimeout(() => {
            const btnContinuar = document.querySelector('button[name="btnContinuar"]') ||
                                 document.querySelector('.sri-boton-mediano-azul') ||
                                 document.querySelector('button[onclick*="srienlinea"]') ||
                                 document.querySelector('a.sri-boton-mediano-azul') ||
                                 document.querySelector('input[type="submit"]');
            if (btnContinuar) {
                btnContinuar.click();
            } else {
                window.location.href = 'https://srienlinea.sri.gob.ec/sri-en-linea/inicio/NAT';
            }
        }, 500);
        return;
    }

    if (isLoginPage) {
        // 💤 Mismo criterio que la barra flotante y el panel (§9c): sin esto,
        // CUALQUIER visita al login del SRI —así el usuario esté ahí por otra
        // razón, con la extensión dormida— precargaba RUC y CLAVE REAL de un
        // cliente pendiente en el formulario, sin que nadie lo pidiera. Un
        // autofill manual pendiente (`pending_sri_autofill.manual`) ya cuenta
        // como "despierta" adentro de extensionDespierta(), así que el ▶
        // del popup y el lote siguen funcionando igual que siempre.
        const despierta = (typeof extensionDespierta === 'function') ? await extensionDespierta() : true;
        if (despierta) {
            renderLoginCockpit(items);
            initLoginCockpitWatcher();
        }
    }

    const isAutoFlow = await SriLoop.puedeAvanzar();
    // 💤 Dormida por defecto: `undefined` cuenta como apagada (antes sólo
    // `=== false`). La despiertan tu web o el popup poniendo el flag en true.
    if (items.sri_master_switch_on !== true && !isAutoFlow) {
        const autofill = items.pending_sri_autofill;
        // Un cliente de LOTE nunca puede despertar la extensión por su cuenta:
        // para eso está el semáforo. Solo un login manual suelto (el botón del
        // popup o del panel) tiene permiso, porque lo acaba de pedir el usuario.
        // Un lote en pausa NO es un lote sin permiso: sus datos se conservan.
        const semAhora = await SriLoop.get();
        const enPausa = semAhora.estado === 'PAUSADO' || semAhora.estado === 'PAUSANDO';
        const esLoteSinPermiso = !!(autofill && autofill.isBatch) && !enPausa && !(await SriLoop.puedeAvanzar());

        if (autofill && autofill.manual && !esLoteSinPermiso) {
            // 🛑 Si el usuario acaba de parar (DETENER/🛑/⏸), el autofill que
            // quedó NO despierta la extensión. El 09-sep-2026 eso era el bucle
            // sin fin: se paraba, y en la próxima página el autofill manual
            // volvía a prender el master, se logueaba y re-armaba la corrida.
            // Parado, se descarta el autofill suelto y queda en reposo; para
            // volver a correr, el usuario lo pide (popup/cockpit) y se rearma.
            //
            // Y aunque NO se haya parado, un autofill suelto es de UN SOLO uso:
            // vale lo que dura su orden (actionTimestamp). Después de 5 minutos
            // ya nadie lo ordena — es un resto, no una corrida — y tampoco
            // despierta. Correr de nuevo = ordenar de nuevo.
            const parado = await sePidioParar();
            const viejo = !!items.actionTimestamp && (Date.now() - items.actionTimestamp > 300000);
            if (parado || viejo) {
                console.warn(`🛑 [PARADA] Autofill suelto de ${autofill.name || autofill.ruc} ` +
                             (parado ? 'pero se pidió parar' : 'pero es viejo (>5 min)') +
                             '. No se despierta; se descarta lo que quedó.');
                await SafeStorage.remove(['pending_sri_autofill', 'pendingAction', 'actionTimestamp',
                                          'auto_batch_queue', 'auto_batch_index']);
                console.log('💤 [SRI ELITE] Modo Reposo: no se rearma nada solo.');
                return;
            }
            console.log('🔓 [SRI ELITE] Login manual solicitado. Despertando extensión...');
            await SafeStorage.set({ sri_master_switch_on: true, sriAutomationPaused: false });
            items.sri_master_switch_on = true;
        } else {
            if (esLoteSinPermiso) {
                console.log('🧹 [BUCLE] Resto de un lote detenido en storage. Se descarta.');
                await SafeStorage.remove(['pending_sri_autofill', 'pendingAction', 'actionTimestamp']);
            }
            console.log('💤 [SRI ELITE] Extensión en Modo Reposo (Apagada). Interacciones canceladas.');
            return;
        }
    }

    // Si el formulario de credenciales está en pantalla, estamos afuera.
    // Antes esto exigía un input llamado 'usuario'; como el de Keycloak no se
    // llama así, la extensión creía estar en la portada y nunca llenaba nada.
    const camposLogin = encontrarCamposLogin();
    const isExplicitlyOutside = !!camposLogin;

    const isAlreadyLoggedIn = !isExplicitlyOutside && (
        !window.location.href.toLowerCase().includes('/auth/realms/') &&
        (
            document.getElementById('id_nombre_razon_social') || 
            document.querySelector('.sri-icon-cerrar-sesion') || 
            document.querySelector('.area-usuario') ||
            document.querySelector('.nombre-contribuyente') ||
            document.querySelector('.sri-icon-perfil') ||
            window.location.href.includes('/perfil') ||
            window.location.href.includes('/declaraciones') ||
            window.location.href.includes('comprobantesRecibidos')
        )
    );

    // ── Blindaje Anti-Bloqueo de Cuenta (Límite 1 Intento por Cliente) ─────────
    // Si el SRI rechaza las credenciales o la página recarga y sigue en el login
    // tras haberlo intentado, NUNCA se reintenta: se detiene al PRIMER intento fallido,
    // se purga el storage, se registra en SriCredentialVault y el bucle ferrocarril continúa.
    // ── Lo que dice el PORTAL, no lo que decimos nosotros ─────────────────
    //
    // `document.body.innerText` incluye la barra flotante de la extensión, sus
    // avisos y el panel de omitidos —donde figuran «clave», «incorrecta» y
    // «error»—. Leer eso y concluir que el SRI rechazó la credencial es el bot
    // leyéndose a sí mismo. Ya nos había mordido en `esPantallaCambioClave()`
    // y volvió a morder el 07-sep-2026: un contribuyente que había entrado
    // quedó marcado con la clave mala.
    //
    // El texto se toma del formulario de acceso del portal, donde la extensión
    // no inyecta nada. Si no hay formulario, no hay de dónde leer y no se
    // concluye nada: eso es `''`, no «no rechazado por defecto» — el rechazo
    // hay que verlo, y no verlo lleva al rebote, que reintenta.
    const dicho = typeof loQueDiceElFormularioDeAcceso === 'function'
        ? loQueDiceElFormularioDeAcceso() : { aviso: '', texto: '' };
    const feedbackText = dicho.aviso;
    const textoDelPortal = dicho.texto;
    const yaIntentoLogin = isLoginPage && isExplicitlyOutside && !!(items.pending_sri_autofill && items.pending_sri_autofill.loginAttempted);
    const isAccountLocked = /(cuenta|usuario) (bloquead|suspendid|inactiv)/i.test(feedbackText || textoDelPortal) ||
        /(n[uú]mero m[aá]ximo|superado el n[uú]mero) de intentos/i.test(feedbackText || textoDelPortal);
    // El portal DIJO que la credencial no sirve. Es lo único que autoriza a
    // anotar `clave_incorrecta`: esa marca escribe en la bóveda y en la ficha
    // web del cliente, y lo deja afuera hasta que alguien la borre a mano.
    const elSriLoRechazo = isLoginPage && (
        isAccountLocked ||
        (feedbackText.length > 0 && /error|inv[aá]lid|incorrect|bloquead|no registrad|superado|fallid/i.test(feedbackText)) ||
        /usuario o contrase[ñn]a (inv[aá]lid|invalid|incorrect)/i.test(textoDelPortal) ||
        /credencial(es)? (inv[aá]lid|incorrect)/i.test(textoDelPortal) ||
        /identificaci[oó]n no registrada/i.test(textoDelPortal)
    );

    if (elSriLoRechazo) {
        // Se deja dicho QUÉ se leyó y DÓNDE. Marcar una clave como mala deja al
        // contribuyente afuera hasta que alguien lo deshaga a mano: el log
        // tiene que permitir discutir la decisión, no sólo anunciarla.
        console.warn('🔎 [LOGIN] El portal rechaza la credencial. Lo que dice el formulario: ' +
                     `«${(feedbackText || textoDelPortal).slice(0, 160).replace(/\s+/g, ' ').trim() || '(nada legible)'}»`);
    }

    // ── Volvimos al login sin que el portal dijera una palabra ─────────────
    // Pasó de verdad el 06-sep-2026: tres contribuyentes entraron —se los vio
    // en /contribuyente/perfil— y al saltar al puente SSO el portal los devolvió
    // a la pantalla de acceso. El bot leyó ese rebote como «clave rechazada» y
    // los marcó a los tres. Un rebote NO es un rechazo: puede ser la sesión que
    // se cayó, el token del puente vencido, o el portal con hipo.
    //
    // Se le da UN segundo intento (dos siguen lejos del bloqueo por intentos) y,
    // si vuelve a rebotar, el cliente queda omitido como `sesion_caida`: sin
    // tocar la bóveda y sin marcarle la clave en la web, porque la clave no
    // tiene por qué estar mal.
    if (yaIntentoLogin && !elSriLoRechazo) {
        const rucRebote = items.pending_sri_autofill?.ruc;
        const nombreRebote = items.pending_sri_autofill?.name || rucRebote || 'este cliente';
        const rb = await SafeStorage.get(['sc_rebotes']);
        const rebotes = rb.sc_rebotes || {};
        const veces = (rebotes[rucRebote] || 0) + 1;

        if (veces <= 1) {
            // DÓNDE rebotó es la pista. Keycloak devuelve
            // `login-actions/authenticate` cuando procesó un intento y no lo
            // dejó pasar; una vuelta a `openid-connect/auth` o a la portada es
            // otra cosa —sesión perdida, token del puente vencido—. La
            // decisión no cambia (sigue siendo un rebote, no una condena),
            // pero el contador necesita saber por dónde empezar a mirar.
            const dondeReboto = /login-actions\/authenticate/.test(location.href)
                ? 'Keycloak procesó el intento y no lo dejó pasar (login-actions/authenticate). ' +
                  'Si se repite en las próximas corridas, mirá esa clave.'
                : 'volvió a la pantalla de acceso sin pasar por la validación.';
            console.warn(`↩️ [REBOTE ${veces}/2] ${nombreRebote}: ${dondeReboto} ` +
                         'El SRI no dio un mensaje, así que no se concluye nada: se reintenta una vez.');
            anotarBitacora('↩️ rebote', `${veces}/2 · ${nombreRebote} volvió al login sin mensaje`);
            rebotes[rucRebote] = veces;
            // No purgar cookies en caliente si ya estamos en la página de Keycloak:
            // borrar la cookie de sesión mientras el form conserva session_code causa HTTP 400.
            await SafeStorage.set({
                sc_rebotes: rebotes,
                pending_sri_autofill: { ...items.pending_sri_autofill, loginAttempted: false }
            });
            items.pending_sri_autofill = { ...items.pending_sri_autofill, loginAttempted: false };
            // Y se sigue de largo: el auto-login de más abajo vuelve a inyectar.
        } else {
            console.error(`🔌 [SESIÓN] ${nombreRebote} rebotó al login dos veces sin mensaje del SRI. ` +
                          'Se lo omite SIN marcarle la clave: no hay nada que diga que esté mal.');
            anotarBitacora('🔌 sesión caída', nombreRebote);
            delete rebotes[rucRebote];
            await SafeStorage.set({ sc_rebotes: rebotes });
            await SafeStorage.remove(['pending_sri_autofill', 'pendingAction', 'actionTimestamp']);

            if (rucRebote) {
                await Omitidos.anotar(rucRebote, 'sesion_caida', {
                    nombre: nombreRebote,
                    detalle: 'Entró y el portal lo devolvió al login, sin mensaje de error'
                });
            }
            if (window.sriAssistant?.showEliteToast) {
                window.sriAssistant.showEliteToast({
                    title: '🔌 Sesión caída',
                    msg: `${nombreRebote} volvió al login sin aviso del SRI. Su clave NO se marcó como mala.`,
                    duration: 8000
                });
            }

            const esLote = items.auto_batch_enabled || items.pending_sri_autofill?.isBatch ||
                (typeof SriLoop !== 'undefined' && await SriLoop.puedeAvanzar());
            if (esLote && typeof handleBatchNextClient === 'function') {
                setTimeout(() => handleBatchNextClient(), 2000);
            }
            return;
        }
    }

    if (elSriLoRechazo) {
        console.error('❌ [LOGIN BLINDAJE] Credenciales erróneas o reintento bloqueado. Deteniendo para blindar la cuenta contra bloqueos.');
        const clientRuc = items.pending_sri_autofill?.ruc;
        const clientPass = items.pending_sri_autofill?.password;
        const clientName = items.pending_sri_autofill?.name || clientRuc || 'este cliente';

        // 🛡️ PURGA INMEDIATA: Borrar credenciales de storage para que ninguna recarga vuelva a enviar la clave mala
        await SafeStorage.remove(['pending_sri_autofill', 'pendingAction', 'actionTimestamp']);

        if (clientRuc && typeof SriCredentialVault !== 'undefined') {
            if (isAccountLocked) {
                await SriCredentialVault.recordLocked(clientRuc, feedbackText || 'Cuenta bloqueada o intentos superados en el SRI');
                await Omitidos.anotar(clientRuc, 'cuenta_bloqueada', { nombre: clientName, detalle: feedbackText });
                await marcarCredencialEnLaWeb(clientRuc, 'bloqueada', feedbackText || 'Cuenta bloqueada en el SRI');
            } else {
                await SriCredentialVault.recordFailure(clientRuc, clientPass, feedbackText || 'Credenciales rechazadas en 1er intento');
                await Omitidos.anotar(clientRuc, 'clave_incorrecta', { nombre: clientName, detalle: feedbackText });
                await marcarCredencialEnLaWeb(clientRuc, 'incorrecta', feedbackText || 'El SRI rechazó la clave guardada');
            }
        } else if (clientRuc) {
            const resErr = await SafeStorage.get(['flagged_errors']);
            const errs = resErr.flagged_errors || {};
            errs[clientRuc] = isAccountLocked ? 'cuenta_bloqueada' : 'error_credenciales';
            await SafeStorage.set({ flagged_errors: errs });
        }
        if (clientRuc && items.pendingAction === 'probar_clave' && typeof PruebaClaves !== 'undefined') {
            await PruebaClaves.anotar(clientRuc, 'rechazada', feedbackText || '', clientName);
        }

        if (window.sriAssistant && typeof window.sriAssistant.showEliteToast === 'function') {
            window.sriAssistant.showEliteToast({
                title: isAccountLocked ? '🚨 Cuenta Bloqueada en SRI' : '🔒 Acceso Detenido (1er Intento)',
                msg: isAccountLocked
                    ? `El SRI reporta que la cuenta de ${clientName} está bloqueada/inactiva. Omitida para continuar el lote.`
                    : `No se pudo ingresar con las credenciales de ${clientName}. Proceso detenido en el 1er intento para proteger la cuenta.`,
                duration: 9000
            });
        }

        const isLoop = items.auto_batch_enabled || (items.pending_sri_autofill && items.pending_sri_autofill.isBatch) || (typeof SriLoop !== 'undefined' && await SriLoop.puedeAvanzar());
        if (isLoop) {
            console.log(`🚂 [FERROCARRIL] Cliente ${clientRuc || ''} omitido con seguridad. Continuando tren al siguiente cliente en 2s...`);
            setTimeout(async () => {
                if (typeof handleBatchNextClient === 'function') {
                    await handleBatchNextClient();
                }
            }, 2000);
        }
        return;
    }


    // Auto-login habilitado si tenemos el RUC del cliente cargado
    const autofillListo = !!(items.pending_sri_autofill && items.pending_sri_autofill.ruc);

    if (isLoginPage && !isAlreadyLoggedIn && autofillListo) {
        const clientRuc = items.pending_sri_autofill.ruc;
        let clientPass = items.pending_sri_autofill.password;
        if (!clientPass) {
            const cacheRes = await SafeStorage.get(['sc_clients_cache']);
            const found = (cacheRes.sc_clients_cache || []).find(c => c.ruc === clientRuc);
            if (found) clientPass = found.password || found.sri_password || found.sriPassword;
        }

        // 🛡️ VERIFICACIÓN PREVENTIVA DE BÓVEDA (ANTES DE TOCAR EL DOM)
        if (typeof SriCredentialVault !== 'undefined') {
            const checkVault = await SriCredentialVault.canAttemptLogin(clientRuc, clientPass);
            if (!checkVault.allowed) {
                console.warn(`🛑 [BLINDAJE SEGURIDAD PREVENTIVO] Omitiendo login de ${clientRuc}: ${checkVault.reason}`);
                await Omitidos.anotar(clientRuc, 'cuenta_bloqueada', {
                    nombre: items.pending_sri_autofill.name, detalle: checkVault.reason });
                await SafeStorage.remove(['pending_sri_autofill', 'pendingAction', 'actionTimestamp']);
                if (window.sriAssistant && typeof window.sriAssistant.showEliteToast === 'function') {
                    window.sriAssistant.showEliteToast({
                        title: '🛡️ Bloqueo Preventivo',
                        msg: `Omitido ${items.pending_sri_autofill.name || clientRuc}: ${checkVault.reason}`,
                        duration: 6000
                    });
                }
                const isLoop = items.auto_batch_enabled || (items.pending_sri_autofill && items.pending_sri_autofill.isBatch) || (typeof SriLoop !== 'undefined' && await SriLoop.puedeAvanzar());
                if (isLoop && typeof handleBatchNextClient === 'function') {
                    setTimeout(() => handleBatchNextClient(), 1500);
                }
                return;
            }
        }

        console.log(`🚀 SRI Assistant: Auto-Login trigger detectado (${items.pending_sri_autofill.name || items.pending_sri_autofill.ruc})...`);
        anotarBitacora('auto-login', items.pending_sri_autofill.name || items.pending_sri_autofill.ruc);

        // Si estamos en Keycloak pero no hay campos de login, es una pantalla de error o sesión rota de Keycloak
        if (window.location.href.includes('/auth/realms/') && !isExplicitlyOutside) {
            console.warn('⚠️ [LOGIN KEYCLOAK] Pantalla de error o sesión expirada de Keycloak (sin campos de credenciales).');
            const restartLink = document.querySelector('a#kc-page-back, a.kc-login-restart, a[href*="login"], a[href*="restart"], a[href*="srienlinea"]');
            if (restartLink && esVisible(restartLink)) {
                console.log('🔄 Reiniciando flujo de login desde enlace de Keycloak...');
                restartLink.click();
                return;
            }
            
            const clientRuc = items.pending_sri_autofill?.ruc;
            const clientName = items.pending_sri_autofill?.name || clientRuc;
            console.warn(`🔌 [SESIÓN] Error en Keycloak para ${clientName}. Omitiendo y avanzando al siguiente cliente...`);
            if (clientRuc) {
                await Omitidos.anotar(clientRuc, 'sesion_caida', {
                    nombre: clientName,
                    detalle: 'Keycloak devolvió pantalla de error (HTTP 400 / sesión caducada)'
                });
            }
            await SafeStorage.remove(['pending_sri_autofill', 'pendingAction', 'actionTimestamp']);
            
            const esLote = items.auto_batch_enabled || items.pending_sri_autofill?.isBatch ||
                (typeof SriLoop !== 'undefined' && await SriLoop.puedeAvanzar());
            if (esLote && typeof handleBatchNextClient === 'function') {
                setTimeout(() => handleBatchNextClient(), 1500);
            } else {
                window.location.href = 'https://srienlinea.sri.gob.ec/sri-en-linea/inicio/NAT';
            }
            return;
        }

        // Si estamos en la portada de inicio del SRI (ej. inicio/NAT), hacer clic en "Iniciar sesión" para ir a Keycloak
        if (!isExplicitlyOutside) {
            console.log('⏳ Esperando que cargue el botón de Iniciar Sesión en la portada...');
            let loginAttempts = 0;
            const loginInterval = setInterval(() => {
                const loginLink = document.querySelector('pre.sri-iniciar-sesion') ||
                                  document.querySelector('.sri-iniciar-sesion') ||
                                  document.querySelector('p.topbar-item-name') ||
                                  document.querySelector('a[href*="openid-connect"]') ||
                                  (typeof findByText === 'function' ? findByText('Iniciar sesión') : null);

                if (loginLink) {
                    clearInterval(loginInterval);
                    console.log('✅ Portada SRI detectada. Clickeando "Iniciar sesión" para ingresar...');
                    if (typeof clickElement === 'function') clickElement(loginLink, 'Iniciar Sesión Portada');
                    else loginLink.click();
                    const parentLink = loginLink.closest('a, button');
                    if (parentLink) parentLink.click();
                }
                
                loginAttempts++;
                if (loginAttempts > 30) {
                    clearInterval(loginInterval);
                    console.warn('⚠️ [LOGIN] No apareció el botón "Iniciar sesión" de la portada tras 6s. Si estabas en la pantalla de credenciales, avisá: el detector no la reconoció.');
                }
            }, 200);
            return;
        }

        let attempts = 0;
        const autoLoginInterval = setInterval(async () => {
            const campos = encontrarCamposLogin();
            const rucInput = campos && campos.ruc;
            const passInput = campos && campos.pass;
            const btn = campos && campos.btn;

            if (rucInput && passInput && btn) {
                console.log('🔑 [LOGIN] Formulario localizado:',
                    `ruc=#${rucInput.id || rucInput.name || '(sin id)'}`,
                    `clave=#${passInput.id || passInput.name || '(sin id)'}`,
                    `botón="${(btn.innerText || btn.value || '').trim()}"`);
                clearInterval(autoLoginInterval);
                let targetPass = items.pending_sri_autofill.password;
                if (!targetPass) {
                    const cacheRes = await SafeStorage.get(['sc_clients_cache']);
                    const found = (cacheRes.sc_clients_cache || []).find(c => c.ruc === items.pending_sri_autofill.ruc);
                    if (found && (found.password || found.sri_password)) {
                        targetPass = found.password || found.sri_password;
                    }
                }

                escribirCampo(rucInput, items.pending_sri_autofill.ruc);
                const hiddenUser = document.getElementById('username');
                if (hiddenUser && hiddenUser !== rucInput) {
                    hiddenUser.value = items.pending_sri_autofill.ruc;
                }
                if (targetPass) {
                    escribirCampo(passInput, targetPass);
                } else {
                    console.warn('⚠️ [LOGIN] Sin clave para este RUC: el formulario queda a medio llenar.');
                }

                // Desactivar overlays de bloqueo de navegador del SRI si estuvieran activos
                ['disablingDiv', 'advertenciaNavegador', 'noSoportado'].forEach(id => {
                    const el = document.getElementById(id);
                    if (el && el.style.display !== 'none') el.style.display = 'none';
                });

                // Guardar la clave en la caché local automáticamente si el usuario la escribe
                passInput.addEventListener('change', async () => {
                    if (passInput.value && rucInput.value) {
                        const cache = await SafeStorage.get(['sc_clients_cache']);
                        const list = cache.sc_clients_cache || [];
                        const idx = list.findIndex(c => c.ruc === rucInput.value);
                        if (idx !== -1) {
                            list[idx].password = passInput.value;
                            list[idx].sri_password = passInput.value;
                            await SafeStorage.set({ sc_clients_cache: list });
                            console.log('💾 Clave SRI guardada localmente para próximas sesiones.');
                        }
                    }
                });

                ['input', 'change', 'blur'].forEach(ev => {
                    rucInput.dispatchEvent(new Event(ev, { bubbles: true }));
                    if (targetPass) passInput.dispatchEvent(new Event(ev, { bubbles: true }));
                });

                await SafeStorage.set({
                    pending_sri_autofill: { ...items.pending_sri_autofill, loginAttempted: true }
                });

                if (!targetPass) {
                    console.log('⚠️ Falta contraseña para este cliente. Esperando ingreso manual...');
                    if (window.sriAssistant) {
                        window.sriAssistant.showEliteToast({
                            title: '🔑 Clave Requerida',
                            msg: 'Ingresa la clave de este cliente una sola vez y la recordaré automáticamente.',
                            duration: 5000
                        });
                    }
                    return;
                }

                console.log('✅ Credenciales inyectadas. Iniciando sesión...');
                setTimeout(() => {
                    if (typeof clickElement === 'function') clickElement(btn, 'Boton Login Keycloak');
                    else btn.click();
                }, 400);
            }
            attempts++;
            if (attempts > 25) clearInterval(autoLoginInterval);
        }, 200);
        return;
    }

    // ── El SRI exige cambiar la clave de este cliente ──────────────────────
    // No se puede declarar hasta resolverlo, y cambiar contraseñas no es algo
    // que este bot haga. Se marca al cliente y el lote sigue con el siguiente.
    const avisoClave = typeof elSriPideCambiarLaClave === 'function'
        ? await elSriPideCambiarLaClave()
        : { pide: esPantallaCambioClave(), mensaje: '', via: 'pantalla' };

    if (avisoClave.pide) {
        const ruc = items.pending_sri_autofill?.ruc;
        const nombre = items.pending_sri_autofill?.name || ruc || 'este contribuyente';
        console.warn(`🔑 [CLAVE] El SRI exige cambiar la clave de ${nombre} (por ${avisoClave.via}). ` +
                     'El bot NO cambia contraseñas.');
        if (avisoClave.mensaje) console.warn(`   El portal dice: «${avisoClave.mensaje}»`);

        if (ruc) {
            const resErr = await SafeStorage.get(['flagged_errors']);
            const errs = resErr.flagged_errors || {};
            errs[ruc] = true;
            await SafeStorage.set({ flagged_errors: errs });
            console.log(`   ${nombre} queda marcado: el lote lo va a omitir.`);
            await Omitidos.anotar(ruc, 'clave_caducada', { nombre });
            await marcarCredencialEnLaWeb(ruc, 'caducada', 'El SRI exige cambiar la clave antes de entrar');
            if (items.pendingAction === 'probar_clave' && typeof PruebaClaves !== 'undefined') {
                await PruebaClaves.anotar(ruc, 'pide_cambio', avisoClave.mensaje || '', nombre);
            }
        }

        if (window.sriAssistant?.showEliteToast) {
            window.sriAssistant.showEliteToast({
                title: '🔑 Clave caducada',
                msg: `El SRI pide cambiar la clave de ${nombre}. Cambiala a mano (extensión 02) y reintentá.`,
                duration: 9000
            });
        }

        if (await SriLoop.puedeAvanzar()) {
            console.log('⏭️ [BUCLE] Saltando al siguiente cliente...');
            anotarBitacora('salta cliente', 'clave caducada');
            await SafeStorage.remove(['pendingAction', 'actionTimestamp', 'pending_sri_autofill']);
            if (typeof handleBatchNextClient === 'function') await handleBatchNextClient();
        }
        return;
    }

    // Antes leía las banderas sueltas: bastaba con basura en storage de una
    // corrida vieja para que arrancara un lote fantasma sin sesión iniciada.
    // isAutoFlow ya evaluado al inicio
    const hasActiveAction = !!(items.pendingAction && (!items.actionTimestamp || (Date.now() - items.actionTimestamp < 120000)));
    const isFreshLogin = !!(items.pending_sri_autofill && items.pending_sri_autofill.loginAttempted);

    if (isAutoFlow && !isAlreadyLoggedIn) {
        // 🚑 RESCATE: el lote está corriendo pero nadie dejó credenciales.
        // Antes se quedaba acá para siempre ("Lote activo pero sin sesión") hasta
        // que el watchdog lo mataba 15 minutos después. El semáforo sabe qué
        // cliente toca: se las preparamos y que el auto-login siga solo.
        if (!items.pending_sri_autofill) {
            const sem = await SriLoop.get();
            const cliente = (sem.cola || [])[sem.indice || 0];
            if (cliente && cliente.password) {
                // Tope de rescates por cliente: si reponer las credenciales no
                // alcanza, algo las borra en cada vuelta y recargar sin límite
                // sería un bucle cerrado. Al segundo intento se frena y avisa.
                const rr = await SafeStorage.get(['sc_rescates']);
                const cont = rr.sc_rescates || {};
                const veces = (cont[cliente.ruc] || 0) + 1;

                // Un lote TERMINADO no se rescata. El 07-sep-2026 el log
                // cerró con tres rescates sobre un contribuyente ya omitido y
                // un «se detiene el lote — algo borra las credenciales»,
                // DESPUÉS de haber anunciado «¡Lote completado!». Un lote que
                // terminó bien no puede despedirse con un mensaje de falla:
                // el que lo lee mañana cree que se rompió.
                // Estar en el último de la cola y sin credenciales significa
                // que ya se lo procesó (u omitió) y el lote se acabó.
                if ((sem.indice || 0) >= (sem.cola || []).length - 1) {
                    console.log('🏁 [BUCLE] El lote ya terminó y este contribuyente quedó omitido. ' +
                                'No hay nada que rescatar.');
                    await SriLoop.detener('Lote terminado');
                    return;
                }

                if (veces > 2) {
                    console.error(`🚑 [RESCATE] ${cliente.name || cliente.ruc} ya se rescató 2 veces y sigue sin credenciales. Se detiene el lote.`);
                    anotarBitacora('⛔ lote detenido', `rescate agotado en ${cliente.name || cliente.ruc}`);
                    await SriLoop.detener('Rescate agotado: algo borra las credenciales en cada vuelta');
                    return;
                }

                cont[cliente.ruc] = veces;
                await SafeStorage.set({ sc_rescates: cont });

                console.warn(`🚑 [RESCATE ${veces}/2] Lote sin credenciales en ${cliente.name || cliente.ruc}. Reponiéndolas desde el semáforo.`);
                anotarBitacora('🚑 rescate', `${veces}/2 · credenciales repuestas: ${cliente.name || cliente.ruc}`);
                await SriLoop.prepararCliente(cliente, sem.periodo || SriLoop.periodoPorDefecto());
                await sleep(400);
                window.location.reload();
                return;
            }
            console.warn('🚑 [RESCATE] El semáforo no tiene un cliente con clave en esta posición. Deteniendo el lote.');
            anotarBitacora('⛔ lote detenido', 'sin cliente con clave en el semáforo');
            await SriLoop.detener('Sin credenciales para el cliente en curso');
            return;
        }
        console.log('⏳ [BUCLE] Lote activo pero sin sesión todavía. Esperando el login.');
        anotarBitacora('esperando login', 'con credenciales');
    } else if (isAlreadyLoggedIn && (isFreshLogin || (!hasActiveAction && (isAutoFlow || (items.pending_sri_autofill && (items.pending_sri_autofill.isBatch || items.pending_sri_autofill.manual)))))) {
        if (typeof SriCredentialVault !== 'undefined' && items.pending_sri_autofill?.ruc) {
            await SriCredentialVault.recordSuccess(items.pending_sri_autofill.ruc, items.pending_sri_autofill.password);
        }
        // Entró bien: si había un aviso de clave en la web, ya no corresponde.
        if (items.pending_sri_autofill?.ruc) {
            marcarCredencialEnLaWeb(items.pending_sri_autofill.ruc, 'ok').catch(() => {});
        }
        // Entró: si venía rebotando, el rebote era del portal y no de la clave.
        if (items.pending_sri_autofill?.ruc) {
            SafeStorage.get(['sc_rebotes']).then((rb) => {
                const rebotes = rb.sc_rebotes || {};
                if (rebotes[items.pending_sri_autofill.ruc] === undefined) return;
                delete rebotes[items.pending_sri_autofill.ruc];
                return SafeStorage.set({ sc_rebotes: rebotes });
            }).catch(() => {});
        }
        // Entró: el rescate (si lo hubo) cumplió. Contador a cero.
        if (items.pending_sri_autofill?.ruc && items.sc_rescates?.[items.pending_sri_autofill.ruc]) {
            const cont = { ...items.sc_rescates };
            delete cont[items.pending_sri_autofill.ruc];
            await SafeStorage.set({ sc_rescates: cont });
        }
        // 👋 Saludo y verificación: primero el perfil, siempre.
        // Si todavía no comprobamos las obligaciones de este cliente, se pasa
        // por el perfil antes que por ninguna otra cosa.
        const quienEntro = items.pending_sri_autofill || {};
        const selloEsperado = quienEntro.ruc && items.workflowPeriod
            ? `${quienEntro.ruc}|${items.workflowPeriod.year}-${String(items.workflowPeriod.monthIndex + 1).padStart(2, '0')}`
            : null;

        // 🔑 Modo «probar claves»: la clave sirvió. Se anota y se sale — nunca
        // navega al perfil ni a ningún wizard, porque eso sería exactamente
        // lo que este modo promete no hacer.
        if (items.pendingAction === 'probar_clave') {
            const ruc = quienEntro.ruc;
            const nombre = quienEntro.name || ruc || 'este contribuyente';
            console.log(`🔑 [PROBAR CLAVES] ${nombre}: clave OK.`);
            if (ruc && typeof PruebaClaves !== 'undefined') {
                await PruebaClaves.anotar(ruc, 'ok', '', nombre);
            }
            await SafeStorage.remove(['pending_sri_autofill', 'pendingAction', 'actionTimestamp']);
            if (typeof handleBatchNextClient === 'function') {
                setTimeout(() => handleBatchNextClient(), 1000);
            }
            return;
        }

        if (selloEsperado &&
            items.pendingAction !== 'recuperar_comprobante' &&
            items.pendingAction !== 'bajar_todos_comprobantes' &&
            items.sri_verificacion_sello !== selloEsperado &&
            !location.href.includes('/contribuyente/perfil')) {
            console.log(`👋 [PERFIL] Antes de nada, verifico las obligaciones de ${quienEntro.name || quienEntro.ruc}.`);
            await SafeStorage.set({ actionTimestamp: Date.now() });
            window.location.href = 'https://srienlinea.sri.gob.ec/sri-en-linea/contribuyente/perfil';
            return;
        }

        // 🧾 Este cliente solo necesita su comprobante: no se le declara nada.
        //
        // La guarda `!enConsultaDeclaraciones()` NO es cosmética. Sin ella esto
        // cruzaba el puente estando ya del otro lado: la página cargaba, este
        // mismo bloque volvía a navegar al mismo sitio, y otra vez. El
        // manejador que de verdad baja el comprobante vive mucho más abajo en
        // esta misma función (`ejecutarRecuperacionComprobante`) y nunca se
        // alcanzaba, porque este `return` cortaba antes.
        //
        // Pasó de verdad el 07-sep-2026: el lote se colgó en el cliente 2 dando
        // vueltas hasta que el usuario apretó 🛑. Es la misma guarda que ya
        // tenía el salto al perfil, tres líneas más arriba.
        if (items.pendingAction === 'recuperar_comprobante' && items.recuperarComprobante &&
            typeof enConsultaDeclaraciones === 'function' && !enConsultaDeclaraciones()) {
            console.log('🧾 Sesión activa: este cliente ya declaró, vamos por su comprobante.');
            await SafeStorage.set({ actionTimestamp: Date.now() });
            window.location.href = SRI_PUENTE_CONSULTA_DECLARACIONES;
            return;
        }

        // 🧾→🚀 Mismo camino que arriba, para «primero el comprobante, después
        // declarar» (10-sep-2026): antes de ir al wizard de recepción, este
        // cliente pasa por Consulta de declaraciones a traer lo que le falte.
        if (items.pendingAction === 'bajar_todos_comprobantes' && items.bajarTodos &&
            typeof enConsultaDeclaraciones === 'function' && !enConsultaDeclaraciones()) {
            console.log('🧾 Sesión activa: primero el comprobante, después declarar. Yendo a Consulta de declaraciones...');
            await SafeStorage.set({ actionTimestamp: Date.now() });
            window.location.href = SRI_PUENTE_CONSULTA_DECLARACIONES;
            return;
        }

        // 📋 Qué pide el SRI para este contribuyente, dicho por el portal.
        // Antes se asumía "el mes pasado" y se esperaba a que el perfil dejara
        // de mostrar la obligación, que tarda ~20 min en actualizarse.
        try {
            let pend = await SriApi.ivaPendiente();

            // Sin respuesta de la API -hoy es lo normal: Keycloak guarda el
            // token en memoria y desde el mundo aislado no se ve- se lee el
            // perfil. veredictoDelPerfil() espera a que Angular lo pinte; sin
            // esa espera devolvía "no lista obligaciones" y el bot se iba a
            // declarar creyendo que no había información.
            if (!pend && typeof SriLoopHUD !== 'undefined' && location.href.includes('/contribuyente/perfil')) {
                const vPrevio = await SriLoopHUD.veredictoDelPerfil();
                const delPanel = vPrevio.veredicto === 'declarar' ? vPrevio.iva : null;
                if (delPanel) {
                    pend = {
                        periodo: delPanel.periodo,
                        periodoTexto: delPanel.periodoTexto,
                        vence: delPanel.vence,
                        dias: undefined,
                        estado: 'Por cumplir',
                        urgencia: 'según el perfil',
                        pendiente: true
                    };
                    console.log(`📋 [PERFIL] La API no contestó, pero el panel del perfil pide: ${delPanel.texto}`);
                }
            }

            if (pend) {
                console.log(`📋 [SRI] IVA ${pend.periodoTexto} · vence ${pend.vence} ` +
                            `(${pend.dias} días, ${pend.urgencia}) · ${pend.estado}`);
                await anotarBitacora('el SRI pide', `IVA ${pend.periodoTexto} · ${pend.estado}`);

                const wp = items.workflowPeriod;
                const mismoPeriodo = !wp ||
                    (wp.year === pend.periodo.year && wp.monthIndex === pend.periodo.monthIndex);

                if (!mismoPeriodo) {
                    console.log(`📋 [SRI] El portal habla de ${pend.periodoTexto}, pero el lote va por ` +
                                `${wp.year}-${String(wp.monthIndex + 1).padStart(2, '0')}. ` +
                                'No se concluye nada de ahí: sigue el flujo normal.');
                } else if (!pend.pendiente) {
                    // ⚠️ NO se salta al cliente por esto, y el motivo importa.
                    //
                    // El aviso de vencimiento cambia alrededor del cierre de
                    // mes: la obligación puede dejar de figurar sin que la
                    // declaración esté hecha. Saltarse a alguien por esa señal
                    // sería dejarlo sin declarar, y eso termina en multa.
                    //
                    // Así que no se cree ni se descree: se va a COMPROBARLO a
                    // Consulta de declaraciones, que es el registro oficial de
                    // lo presentado. Y si efectivamente está, de paso se baja
                    // su comprobante — que es lo que faltaba para cerrar el
                    // objetivo. Si no aparece, se declara normalmente.
                    console.log(`🔍 [SRI] El aviso dice "${pend.estado}" para ${pend.periodoTexto}. ` +
                                'No alcanza para saltarlo: se comprueba en Consulta de declaraciones.');
                    await anotarBitacora('a comprobar', `${pend.periodoTexto} · el aviso dice ${pend.estado}`);

                    const quien = items.pending_sri_autofill || {};
                    if (quien.ruc && typeof irARecuperarComprobante === 'function') {
                        if (window.sriAssistant?.showEliteToast) {
                            window.sriAssistant.showEliteToast({
                                title: '🔍 Comprobando',
                                msg: `El portal marca ${pend.periodoTexto} como ${pend.estado}. ` +
                                     'Voy a verificarlo y a traer el comprobante.',
                                duration: 6000
                            });
                        }
                        await irARecuperarComprobante(quien.ruc, pend.periodo, quien.name);
                        return;
                    }
                    // Sin RUC no hay nada que comprobar: sigue el flujo normal.
                }

                if (!items.workflowPeriod) {
                    // Sin período fijado por el lote, el del portal es el bueno.
                    items.workflowPeriod = pend.periodo;
                    await SafeStorage.set({ workflowPeriod: pend.periodo });
                    console.log(`📋 [SRI] Período tomado del portal: ${pend.periodoTexto}.`);
                }
                await SafeStorage.set({ sri_obligacion_actual: pend });
                if (selloEsperado) await SafeStorage.set({ sri_verificacion_sello: selloEsperado });
            } else if (typeof SriLoopHUD !== 'undefined') {
                // Sin obligación pendiente a la vista, el perfil todavía tiene
                // algo que decir: si este contribuyente declara IVA o no.
                const v = await SriLoopHUD.veredictoDelPerfil();
                console.log(`📋 [PERFIL] Veredicto: ${v.veredicto} — ${v.motivo}`);
                await anotarBitacora('veredicto del perfil', `${v.veredicto} · ${v.motivo}`);

                if (v.veredicto === 'no_declara_iva' && quienEntro.ruc) {
                    // No es un error ni un olvido: este cliente no declara IVA.
                    if (typeof Omitidos !== 'undefined') {
                        await Omitidos.anotar(quienEntro.ruc, 'no_declara_iva',
                            { nombre: quienEntro.name, detalle: v.motivo });
                    }
                    await SafeStorage.remove(['pendingAction', 'actionTimestamp']);
                    if (await SriLoop.puedeAvanzar() && typeof handleBatchNextClient === 'function') {
                        const hay = await handleBatchNextClient();
                        if (!hay && typeof cerrarSesionSRI === 'function') await cerrarSesionSRI();
                    }
                    return;
                }

                if (v.veredicto === 'ya_declarada' && quienEntro.ruc && items.workflowPeriod &&
                    typeof irARecuperarComprobante === 'function') {
                    // El caso que cierra el objetivo: ya declaró y le falta el
                    // comprobante. No se declara a ciegas: se confirma en la
                    // lista de presentadas y se baja el PDF.
                    if (window.sriAssistant?.showEliteToast) {
                        window.sriAssistant.showEliteToast({
                            title: '✅ Ya estaba declarada',
                            msg: `${quienEntro.name || quienEntro.ruc} tiene la obligación de IVA y ` +
                                 'no figura pendiente. Voy a confirmarlo y traer su comprobante.',
                            duration: 7000
                        });
                    }
                    if (selloEsperado) await SafeStorage.set({ sri_verificacion_sello: selloEsperado });
                    await irARecuperarComprobante(quienEntro.ruc, items.workflowPeriod, quienEntro.name);
                    return;
                }
                // 'no_concluyo' → sigue el flujo normal, que tiene sus propios frenos.
            }
        } catch (e) { /* la consulta nunca puede frenar el flujo */ }

        // ── El atajo no se pisa ─────────────────────────────────────────────
        // Este bloque corre en CADA carga con sesión abierta, y hasta el
        // 07-sep-2026 terminaba siempre plantando `turbo_step1_facturas`.
        // Cuando el perfil ya había decidido ir a buscar un comprobante, la
        // página siguiente lo borraba y mandaba a extraer facturas de un
        // contribuyente que ya había declarado: 19 facturas, retenciones,
        // notas de crédito y el wizard entero, para que el paso 4 dijera lo
        // que el perfil ya había dicho al principio.
        //
        // No rompía nada —el freno de la sustitutiva agarraba al final— así
        // que costaba un minuto por cliente sin que se notara.
        //
        // Las acciones de abajo son DECISIONES ya tomadas, no pasos de una
        // secuencia: quien las puso sabía más que este bloque, que llega a
        // esta línea justamente cuando NO supo concluir nada.
        const YA_DECIDIDAS = ['recuperar_comprobante', 'bajar_todos_comprobantes', 'bajarTodos'];
        if (YA_DECIDIDAS.includes(items.pendingAction)) {
            console.log(`🎯 [FLUJO] Ya hay algo decidido en curso («${items.pendingAction}»). ` +
                        'No se planta la extracción encima: eso rehacía todo el trabajo.');
            console.log('🔄 Recuperando estado pendiente:', items);
            const ghostData = await GhostMemory.getData();
            ejecutarAccionPendiente({ ...ghostData, ...items });
            return;
        }

        // 🛑 Parado, la sesión activa NO replanta la corrida sola: sin este
        // candado, después de un DETENER el perfil volvía a plantar
        // turbo_step1_facturas y el bucle seguía (09-sep-2026).
        if (await sePidioParar()) {
            console.warn('🛑 [PARADA] Sesión activa pero se pidió parar: no se replanta turbo_step1.');
            await SafeStorage.remove(['pendingAction', 'actionTimestamp']);
            return;
        }
        console.log('🚀 Sesión activa detectada: Redirigiendo DIRECTO al Paso 1: Comprobantes Recibidos...');
        items.pendingAction = 'turbo_step1_facturas';
        const now = new Date();
        let cMonth = now.getMonth() - 1;
        let cYear = now.getFullYear();
        if (cMonth < 0) { cMonth = 11; cYear--; }
        items.workflowPeriod = items.workflowPeriod || { year: cYear, monthIndex: cMonth };
        items.actionTimestamp = Date.now();
        
        await SafeStorage.set({
            pendingAction: 'turbo_step1_facturas',
            checkFacturas: true,
            checkRetenciones: true,
            checkNC: true,
            workflowPeriod: items.workflowPeriod,
            actionTimestamp: items.actionTimestamp,
            pending_sri_autofill: { ...(items.pending_sri_autofill || {}), loginAttempted: false },
            sriAutomationPaused: false,
            ghost_manual_mode: false,
            sri_auto_mode: true,
            autoDeclaration: true,
            skipSafetyCheck: true
        });

        // Si ya estamos adentro y no estamos en la página de comprobantes recibidos, redirigir ordenadamente
        if (!window.location.href.toLowerCase().includes('comprobantesrecibidos.jsf')) {
            console.log('✈️ [AUTO FLIGHT] Navegando a Comprobantes Recibidos (Paso 1)...');
            if (typeof navegarAComprobantes === 'function') {
                navegarAComprobantes();
            } else {
                window.location.href = SRI_PUENTE_RECIBIDOS;
            }
            return;
        }
    } else if (items.pending_sri_autofill && items.pending_sri_autofill.loginAttempted) {
        // En login manual suelto: Respetar navegación manual
        console.log('ℹ️ Login completado. Control manual respetado (sin auto-redirección).');
        await SafeStorage.set({
            pending_sri_autofill: { ...items.pending_sri_autofill, loginAttempted: false }
        });
    }

    if (items.pendingAction) {
        if (isLoginPage && !isAlreadyLoggedIn && (items.pendingAction === 'startIvaNavigation' || items.pendingAction === 'verifyProfile' || items.pendingAction.includes('turbo'))) {
            if (autofillListo) {
                console.log('🔑 SRI Assistant: En el login con credenciales cargadas. El auto-login se encarga.');
            } else {
                console.log('🛑 SRI Assistant: Detectado Login sin credenciales. Esperando a que el usuario ingrese...');
            }
            return;
        }

        // 🛑 Última red: si quedó una acción pendiente pero se pidió parar, no
        // se ejecuta — se descarta (carrera entre el clic de DETENER y la
        // escritura del storage en la página que se está cerrando).
        if (await sePidioParar()) {
            console.warn(`🛑 [PARADA] Acción «${items.pendingAction}» pendiente pero se pidió parar. Se descarta.`);
            await SafeStorage.remove(['pendingAction', 'actionTimestamp', 'accionEnCurso', 'accionVueltas']);
            return;
        }

        console.log('🔄 Recuperando estado pendiente:', items);
        GhostMemory.getData().then(ghostData => {
            ejecutarAccionPendiente({ ...ghostData, ...items });
        });
    }
});

async function ejecutarAccionPendiente(items) {
    // 🚪 Página puente del SSO: solo redirige. No hay nada que hacer acá.
    if (location.search.includes('token=') &&
        !document.getElementById('frmPrincipal:ano') &&
        !document.getElementById('formPresentada:tblConsultaDeclaracion')) {
        console.log('🚪 [PUENTE] Página de traspaso del SSO. Espero la redirección.');
        await SafeStorage.set({ actionTimestamp: Date.now() });
        return;
    }

    // 🔄 AUTO-RECOVERY: Si estamos en Comprobantes Recibidos con lote en marcha pero sin pendingAction
    if ((!items || !items.pendingAction) && window.location.href.toLowerCase().includes('comprobantesrecibidos.jsf')) {
        let sem = null;
        if (typeof SriLoop !== 'undefined') {
            try { sem = await SriLoop.get(); } catch (e) {}
        }
        if (sem && sem.estado === 'CORRIENDO') {
            console.log('🔄 [AUTO-RECOVERY] En Comprobantes Recibidos con lote activo. Restaurando turbo_step1_facturas...');
            if (!items) items = {};
            items.pendingAction = 'turbo_step1_facturas';
            if (!items.workflowPeriod && sem.periodo) items.workflowPeriod = sem.periodo;
            await SafeStorage.set({
                pendingAction: 'turbo_step1_facturas',
                workflowPeriod: items.workflowPeriod,
                actionTimestamp: Date.now()
            });
        }
    }

    if (!items || !items.pendingAction) return;

    // ELITE v10.5: TIMESTAMP CHECK (STALE ACTION PROTECTION)
    if (items.actionTimestamp) {
        const diff = Date.now() - items.actionTimestamp;
        if (diff > 120000) { // 2 minutos (120,000 ms)
            console.log(`💀 Acción Caducada detectada (${items.pendingAction}, ${Math.round(diff / 1000)}s old). Limpiando...`);
            await SafeStorage.remove(['pendingAction', 'actionTimestamp', 'workflowPeriod', 'sriAutomationPaused']);
            return;
        }
    } else {
        if (window.location.href.includes('inicio.jsf') || window.location.href.includes('login')) {
            console.log('💀 Acción Legacy sin timestamp en Inicio. Limpiando...');
            await SafeStorage.remove(['pendingAction']);
            return;
        }
    }

    // 🚦 Si la acción pertenece a un lote, la autoridad es el semáforo.
    // Sin esto, un pendingAction heredado revivía el lote solo, chocaba contra
    // la pantalla de login y moría ("entra un segundo y sale").
    const esDeLote = !!(items.pending_sri_autofill && items.pending_sri_autofill.isBatch);
    if (esDeLote && typeof SriLoop !== 'undefined' && !(await SriLoop.puedeAvanzar())) {
        const sem = await SriLoop.get();
        if (sem.estado === 'PAUSADO' || sem.estado === 'PAUSANDO') {
            // En pausa NO se toca nada: el cliente y su acción quedan esperando.
            console.log(`⏸️ [BUCLE] En pausa en ${items.pending_sri_autofill.name || items.pending_sri_autofill.ruc}. Todo queda guardado; pulsá ▶ para seguir.`);
            anotarBitacora('en pausa', items.pending_sri_autofill.name || items.pending_sri_autofill.ruc);
            return;
        }
        console.log('🧹 Acción de lote descartada: el semáforo está DETENIDO. Usá ▶ para arrancar.');
        await SafeStorage.remove(['pendingAction', 'actionTimestamp', 'workflowPeriod', 'pending_sri_autofill']);
        return;
    }

    // 🪪 La sesión abierta debe ser la del cliente que el lote está declarando.
    if (esDeLote && items.pending_sri_autofill?.ruc) {
        const esperado = items.pending_sri_autofill.ruc;

        // Prueba dura: el propio portal dice quién está adentro.
        let enPantalla = {};
        let fuente = '';
        try {
            const p = await SriApi.perfil();
            if (p && p.identificacion) {
                enPantalla = { ruc: String(p.identificacion), highConfidence: true };
                fuente = 'la API del perfil';
                if (enPantalla.ruc !== esperado) {
                    console.error(`🪪 [IDENTIDAD] El portal dice que la sesión es de ${enPantalla.ruc}, ` +
                                  `y el lote espera a ${esperado}.`);
                }
            }
        } catch (e) { /* sin API, seguimos con la cabecera */ }

        if (!enPantalla.ruc && window.sriAssistant && window.sriAssistant.extractClientInfo) {
            enPantalla = window.sriAssistant.extractClientInfo() || {};
            fuente = 'la cabecera de la página';
        }

        // ── El sello gana sobre la cabecera ──
        // El SSO salta entre aplicaciones JSF distintas y cada una tiene su
        // propia cabecera. La de comprobantesRecibidos.jsf llegaba servida del
        // cliente ANTERIOR, y por creerle el lote entraba y salía sin fin.
        // Si el SRI aceptó la clave de este RUC hace un momento, la sesión es
        // suya: eso lo dijo el portal, no una cabecera cacheada.
        const sello = (await SafeStorage.get(['sc_sesion_confirmada'])).sc_sesion_confirmada;
        const selloFresco = !!(sello && sello.ruc === esperado &&
                               (Date.now() - (sello.ts || 0)) < 360000);
        const soloCabecera = fuente === 'la cabecera de la página';

        if (selloFresco && soloCabecera && enPantalla.ruc && enPantalla.ruc !== esperado) {
            console.warn(`🪪 [IDENTIDAD] La cabecera muestra a ${enPantalla.ruc}, pero el SRI aceptó la clave ` +
                         `de ${esperado} hace ${Math.round((Date.now() - sello.ts) / 1000)}s. ` +
                         'Es la cabecera vieja de otra pantalla: sigo con el cliente correcto.');
            enPantalla = {};
        }

        if (enPantalla.ruc && enPantalla.highConfidence && enPantalla.ruc !== esperado) {
            console.error(`🪪 [IDENTIDAD] La sesión abierta es de ${enPantalla.ruc} pero el lote espera a ${esperado}. ` +
                          'No se toca nada: se purga la sesión y se avanza al siguiente cliente del lote.');
            anotarBitacora('⛔ identidad no coincide', `sesión=${enPantalla.ruc} · esperado=${esperado}`);

            // Cada reintento es un login más. Dos alcanzan: al tercero se
            // frena el lote entero antes de que el SRI bloquee la cuenta.
            const kIntentos = 'sc_identidad_intentos';
            const intentos = (await SafeStorage.get([kIntentos]))[kIntentos] || {};
            intentos[esperado] = (intentos[esperado] || 0) + 1;
            await SafeStorage.set({ [kIntentos]: intentos });
            if (intentos[esperado] >= 3) {
                console.error(`🛑 [IDENTIDAD] Tercer desencuentro seguido con ${esperado}. ` +
                              'Freno el lote: seguir sería martillar el login del SRI y arriesgar el bloqueo de la cuenta.');
                anotarBitacora('🛑 lote detenido', `identidad irresoluble en ${esperado}`);
                if (typeof SriLoop !== 'undefined') await SriLoop.detener('identidad irresoluble');
                await SafeStorage.remove(['pending_sri_autofill', 'pendingAction', 'actionTimestamp']);
                if (typeof cerrarSesionSRI === 'function') await cerrarSesionSRI(true);
                return;
            }
            await Omitidos.anotar(esperado, 'identidad', {
                nombre: items.pending_sri_autofill?.name || 'Cliente',
                detalle: `la sesión abierta era de ${enPantalla.ruc}` });
            await SafeStorage.remove(['pending_sri_autofill', 'pendingAction', 'actionTimestamp']);
            if (typeof handleBatchNextClient === 'function') {
                const batchNext = await handleBatchNextClient();
                if (!batchNext && typeof cerrarSesionSRI === 'function') {
                    await cerrarSesionSRI(true);
                }
            } else if (typeof cerrarSesionSRI === 'function') {
                await cerrarSesionSRI(true);
            }
            return;
        }

        // Identidad en orden: se borra el historial de tropiezos de este
        // cliente para que un desencuentro viejo no lo condene mañana.
        const kOk = 'sc_identidad_intentos';
        const previos = (await SafeStorage.get([kOk]))[kOk] || {};
        if (previos[esperado]) {
            delete previos[esperado];
            await SafeStorage.set({ [kOk]: previos });
        }
    }

    if (!(await verifySessionConsistency())) return;

    if (!(await checkSessionAlive())) {
        const url = window.location.href.toLowerCase();
        if (url.includes('/auth/realms/') || url.includes('login')) {
            console.log('🔒 Esperando login del usuario...');
            return;
        }
        return;
    }

    console.log(`🔎 Acción pendiente detectada: ${items.pendingAction}`);

    let retries = 0;
    while ((!window.sriAssistant || !window.sriAssistant.container) && retries < 20) {
        await sleep(200);
        retries++;
    }

    // ELITE v10.3: SAFETY STOP BYPASS
    // Si la acción fue iniciada intencionalmente (ej. Turbo), skipSafetyCheck suele ser true.
    const shouldVerify = !items.skipSafetyCheck;

    if (window.sriAssistant && shouldVerify) {
        // --- INTERCEPTOR DE RECUPERACIÓN ESTRICTO (Manual Confirm) ---
        const shouldContinue = await new Promise(resolve => {
            window.sriAssistant.showContextCard({
                title: '🔄 Tarea Pendiente',
                subtitle: 'Recuperando Sesión',
                message: `Se ha detectado una tarea pausada:<br><b>${items.pendingAction}</b>.<br><br>¿Deseas continuar o cancelar?`,
                icon: '⏱️',
                // 🛑 timeout:null = sin cuenta regresiva. Esta tarjeta pregunta,
                // no informa: no puede auto-confirmarse sola a los 4 segundos.
                timeout: null,
                actionText: '▶ CONTINUAR',
                onAction: () => {
                    const card = document.getElementById('sri-context-card');
                    if (card) card.remove();
                    window.sriAssistant.contextCard = null;
                    resolve(true);
                }
            });

            // Agregamos botón secundario de cancelar manualmente a la tarjeta
            setTimeout(() => {
                const card = document.getElementById('sri-context-card');
                if (card) {
                    const btnContainer = card.querySelector('.sri-cc-actions') || card;
                    const cancelBtn = document.createElement('button');
                    cancelBtn.style.cssText = "background: rgba(239, 68, 68, 0.15); color: #f87171; border: 1px solid rgba(239,68,68,0.3); padding: 8px 12px; border-radius: 8px; font-size: 11px; font-weight: 700; cursor: pointer; margin-top: 8px; width: 100%;";
                    cancelBtn.innerText = '⛔ CANCELAR TAREA';
                    cancelBtn.onclick = async () => {
                        await SafeStorage.remove(['pendingAction', 'workflowPeriod']);
                        window.sriAssistant.showEliteToast({ title: '🛑 Detenido', msg: 'Tarea cancelada y limpiada por el usuario.' });
                        window.sriAssistant.setWorking(false);
                        card.remove();
                        window.sriAssistant.contextCard = null;
                        resolve(false);
                    };
                    btnContainer.appendChild(cancelBtn);
                }
            }, 500);
        });

        if (!shouldContinue) return;
    }

    if (window.sriAssistant && window.sriAssistant.container) {
        // --- ELITE SENSE: Verificar que el cliente no haya cambiado antes de automatizar ---
        if (window.sriAssistant.checkRucChange) {
            await window.sriAssistant.checkRucChange();
        }

        window.sriAssistant.setWorking(true);
        window.sriAssistant.toggleMinimize(true);
    }

    // detector de pausa persistente
    // El semáforo se consulta acá: isAutoFlow vive en el callback de arranque
    // y desde esta función no se ve.
    const enAutomatico = typeof SriLoop !== 'undefined' ? await SriLoop.puedeAvanzar() : false;
    const paused = await isPaused();
    if (paused) {
        // ELITE FIX: Si hay un flujo automático explícito activo ordenado recientemente (<120s),
        // despausar automáticamente para evitar quedar bloqueado por un estado pausado previo
        if (enAutomatico && items.actionTimestamp && (Date.now() - items.actionTimestamp < 120000)) {
            console.log('🔓 [AUTORUN] Flujo automático activo detectado (<120s). Reactivando sistema previamente pausado...');
            await SafeStorage.set({ sriAutomationPaused: false, ghost_manual_mode: false });
            if (window.sriAssistant) {
                window.sriAssistant.isPaused = false;
                window.sriAssistant.manualMode = false;
                window.sriAssistant.updatePauseUI();
            }
        } else {
            console.log('⏸️ El sistema está pausado. No se retomarán acciones pendientes.');
            if (window.sriAssistant) {
                window.sriAssistant.isPaused = true;
                window.sriAssistant.render();
            }
            return;
        }
    }

    // --- WORKFLOW TURBO (CICLO COMPLETO) ---
    let currentAction = items.pendingAction;
    if (currentAction?.startsWith('turbo_')) {
        console.log(`🚀 MODO TURBO (Local State): ${currentAction}`);

        // Si no estamos en la página de comprobantes recibidos, redirigir directamente
        if (!window.location.href.toLowerCase().includes('comprobantesrecibidos.jsf')) {
            console.log('🚀 [MODO TURBO] Redirigiendo vía puente a Comprobantes Recibidos...');
            if (typeof renderEmergencyStopBar === 'function') renderEmergencyStopBar();
            window.location.href = SRI_PUENTE_RECIBIDOS;
            return;
        }

        if (typeof renderEmergencyStopBar === 'function') renderEmergencyStopBar();

        // Fase 1: Configurar Búsqueda Facturas
        if (currentAction === 'turbo_step1_facturas') {
            const searchRes = await autoLlenarBusqueda({
                ...items.workflowPeriod,
                tipoComprobante: 'Factura',
                autoClickConsultar: true,
                nextStep: 'turbo_step2_extraer_facturas'
            });

            if (searchRes.noData) {
                console.log('ℹ️ Confirmado: No hay Facturas para este periodo.');
                await GhostMemory.set('facturas', { totalFacturas: 0, iva15: { cantidad: 0 }, iva0: { cantidad: 0 } });
                const nextAction = getNextTurboStep('turbo_step2_extraer_facturas', items);
                if (nextAction === 'FIN_TURBO') {
                    currentAction = 'FIN_TURBO';
                } else {
                    await SafeStorage.set({ pendingAction: nextAction, actionTimestamp: Date.now() });
                    window.location.reload();
                    return;
                }
            } else if (searchRes.tableFound && searchRes.desdeTxt && Array.isArray(searchRes.filasTxt)) {
                console.log(`📊 [TXT OFICIAL] Procesando ${searchRes.filasTxt.length} facturas recuperadas directamente desde el listado TXT del SRI...`);
                let rucsAl5 = new Set();
                if (typeof Proveedores !== 'undefined') {
                    try {
                        await Proveedores.registrarLote(searchRes.filasTxt, await rucDelClienteActual());
                        rucsAl5 = await Proveedores.losQueFacturanAl5();
                    } catch (e) { console.warn('🏷️ [PROVEEDORES] Error anotando desde TXT:', e.message); }
                }
                const res = (typeof calcularResumen === 'function')
                    ? calcularResumen(searchRes.filasTxt, { rucsAl5 })
                    : { totalFacturas: searchRes.filasTxt.length };
                await GhostMemory.set('facturas', res);
                console.log(`✅ [TXT OFICIAL] Facturas procesadas y guardadas: ${res.totalFacturas || searchRes.filasTxt.length}`);

                const nextAction = getNextTurboStep('turbo_step2_extraer_facturas', items);
                await SafeStorage.set({
                    pendingAction: nextAction,
                    actionTimestamp: Date.now()
                });
                if (nextAction === 'FIN_TURBO') {
                    currentAction = 'FIN_TURBO';
                } else {
                    window.location.reload();
                    return;
                }
            } else if (!searchRes.tableFound && searchRes.error) {
                console.warn('⚠️ [ALERTA] La búsqueda de facturas no concluyó en el portal SRI. Reintentando consulta...');
                await SafeStorage.set({ pendingAction: 'turbo_step1_facturas' });
                await sleep(1500);
                window.location.reload();
                return;
            } else {
                currentAction = 'turbo_step2_extraer_facturas';
            }
        }

        // Fase 2: Extraer Facturas
        if (currentAction === 'turbo_step2_extraer_facturas') {
            await waitFor(() => document.querySelectorAll('td').length > 5 && document.body.innerText.includes('RUC'), 20000, 'Tabla Facturas');
            if (window.sriAssistant) window.sriAssistant.log('📊 Extrayendo facturas automáticamente...');
            const res = await extraerTodasLasFacturas();
            await GhostMemory.set('facturas', res);

            try {
                const informe = await auditarExtraccionConTxt(
                    TIPO_COMPROBANTE.factura, res.totalFacturas || 0);
                if (informe) {
                    await GhostMemory.set('auditoriaFacturas', informe);
                    // Los proveedores del período salen gratis acá: son el
                    // insumo del laboratorio de clasificación.
                    if (informe.proveedores.length) {
                        await SafeStorage.set({ sc_proveedores_periodo: informe.proveedores });
                        console.log(`🧪 [PROVEEDORES] ${informe.proveedores.length} emisores distintos en el período.`);
                    }
                }
            } catch (e) { /* auditar nunca puede frenar la extracción */ }

            const nextAction = getNextTurboStep('turbo_step2_extraer_facturas', items);
            await SafeStorage.set({
                pendingAction: nextAction,
                actionTimestamp: Date.now()
            });

            if (nextAction === 'FIN_TURBO') {
                currentAction = 'FIN_TURBO';
            } else {
                window.location.reload();
                return;
            }
        }

        // Fase 3: Configurar Búsqueda Retenciones
        if (currentAction === 'turbo_step3_retenciones') {
            const searchRes = await autoLlenarBusqueda({
                ...items.workflowPeriod,
                tipoComprobante: 'Retencion',
                autoClickConsultar: true,
                nextStep: 'turbo_step4_extraer_retenciones'
            });

            if (searchRes.noData) {
                console.log('ℹ️ Confirmado fehacientemente: No hay retenciones para este periodo.');
                await GhostMemory.set('retenciones', { totalRetenciones: 0, ivaRetenido: { total: 0 }, rentaRetenida: { total: 0 }, listaNumeros: [] });

                const nextAction = getNextTurboStep('turbo_step4_extraer_retenciones', items);
                if (nextAction === 'FIN_TURBO') {
                    currentAction = 'FIN_TURBO';
                } else {
                    await SafeStorage.set({ pendingAction: nextAction, actionTimestamp: Date.now() });
                    await sleep(1000);
                    window.location.reload();
                    return;
                }
            } else if (!searchRes.tableFound && searchRes.error) {
                console.warn('⚠️ [ALERTA] La búsqueda de retenciones no concluyó de forma fehaciente en el portal SRI. Reintentando consulta...');
                if (window.sriAssistant) window.sriAssistant.log('⚠️ Reintentando búsqueda de retenciones (sin respuesta del SRI)...');
                await SafeStorage.set({ pendingAction: 'turbo_step3_retenciones' });
                await sleep(1500);
                window.location.reload();
                return;
            } else {
                currentAction = 'turbo_step4_extraer_retenciones';
            }
        }

        // Fase 4: Extraer Retenciones
        if (currentAction === 'turbo_step4_extraer_retenciones') {
            await waitFor(() => document.querySelectorAll('td').length > 5 && document.body.innerText.includes('Comprobante'), 10000, 'Tabla Retenciones');
            if (window.sriAssistant) window.sriAssistant.log('📊 Extrayendo retenciones automáticamente...');
            const res = await extraerTodasLasRetenciones();
            await GhostMemory.set('retenciones', res);

            const nextAction = getNextTurboStep('turbo_step4_extraer_retenciones', items);
            await SafeStorage.set({
                pendingAction: nextAction,
                actionTimestamp: Date.now()
            });

            if (nextAction === 'FIN_TURBO') {
                currentAction = 'FIN_TURBO';
            } else {
                window.location.reload();
                return;
            }
        }

        // Fase 5: Configurar Búsqueda Notas de Crédito
        if (currentAction === 'turbo_step5_notas_credito') {
            const searchRes = await autoLlenarBusqueda({
                ...items.workflowPeriod,
                tipoComprobante: 'Nota de Crédito',
                autoClickConsultar: true,
                nextStep: 'turbo_step6_extraer_notas_credito'
            });

            if (searchRes.noData) {
                console.log('ℹ️ Confirmado fehacientemente: No hay Notas de Crédito para este periodo.');
                await GhostMemory.set('notasCredito', { totalNotas: 0, iva: { total: 0 }, totalGeneral: 0 });
                currentAction = 'FIN_TURBO';
            } else if (!searchRes.tableFound && searchRes.error) {
                console.warn('⚠️ [ALERTA] La búsqueda de notas de crédito no concluyó fehacientemente. Reintentando...');
                if (window.sriAssistant) window.sriAssistant.log('⚠️ Reintentando búsqueda de notas de crédito...');
                await SafeStorage.set({ pendingAction: 'turbo_step5_notas_credito' });
                await sleep(1500);
                window.location.reload();
                return;
            } else {
                currentAction = 'turbo_step6_extraer_notas_credito';
            }
        }

        // Fase 6: Extraer Notas de Crédito (NUEVO)
        if (currentAction === 'turbo_step6_extraer_notas_credito') {
            await waitFor(() => document.querySelectorAll('td').length > 5 && document.body.innerText.includes('RUC'), 10000, 'Tabla Notas Crédito');
            if (window.sriAssistant) window.sriAssistant.log('📊 Extrayendo Notas de Crédito automáticamente...');
            const res = await extraerTodasLasNotasCredito();
            await GhostMemory.set('notasCredito', res);

            await SafeStorage.remove(['pendingAction']);
            currentAction = 'FIN_TURBO';
        }

        if (currentAction === 'FIN_TURBO') {
            // ELITE BULK: Manejar transición entre meses
            if (items.bulkFlow && items.bulkFlow.active) {
                const resultsStorage = await GhostMemory.getData();
                const currentMonthIndex = items.bulkFlow.currentIndex;

                // Guardar resultados del mes actual en el acumulador bulk
                const newResults = [...(items.bulkFlow.results || [])];
                newResults.push({
                    month: items.bulkFlow.months[currentMonthIndex],
                    data: resultsStorage
                });

                // ELITE FIX: Guardar el nuevo estado del bulkflow para usarlo en esta misma ejecución si es el fin
                items.bulkFlow.results = newResults;

                const nextIndex = currentMonthIndex + 1;
                if (nextIndex < items.bulkFlow.months.length) {
                    const nextMonth = items.bulkFlow.months[nextIndex];
                    const nextFirstStep = getNextTurboStep(null, { ...items, bulkFlow: { ...items.bulkFlow, results: newResults } });

                    if (window.sriAssistant) {
                        window.sriAssistant.log(`🌔 Mes ${items.bulkFlow.months[currentMonthIndex]} completado. Saltando a mes ${nextMonth}...`);
                    }

                    await SafeStorage.set({
                        workflowPeriod: { ...items.workflowPeriod, monthIndex: nextMonth },
                        bulkFlow: { ...items.bulkFlow, currentIndex: nextIndex, results: newResults },
                        pendingAction: nextFirstStep,
                        actionTimestamp: Date.now()
                    });

                    // Limpiar memoria temporal para el siguiente mes
                    await GhostMemory.clearCurrent();

                    await sleep(1000);
                    window.location.reload();
                    return;
                } else {
                    // FIN DEL BULK TOTAL
                    console.log('🏆 FIN DE EXTRACCIÓN MASIVA.');
                    if (window.sriAssistant) window.sriAssistant.log('🏆 FIN DE EXTRACCIÓN MASIVA.');

                    // Actualizar para el bloque de agregación mas adelante
                    items.pendingAction = 'FIN_TURBO_BULK';
                    items.bulkFlow.active = false;

                    await SafeStorage.set({
                        bulkFlow: { ...items.bulkFlow, results: newResults, active: false },
                        pendingAction: 'FIN_TURBO_BULK'
                    });
                    currentAction = 'FIN_TURBO_BULK';
                }
            }

            if (currentAction === 'FIN_TURBO') {
                await SafeStorage.remove(['pendingAction']);
                const storage = await SafeStorage.get(['autoDeclaration']);
                const porSemaforo = await SriLoop.puedeAvanzar();
                const porBandera = storage.autoDeclaration === true;
                const isAuto = porSemaforo || porBandera;
                console.log(`🔀 [FASE 1→2] Extracción lista. ¿Pasar a declarar? ${isAuto ? 'SÍ' : 'NO'} ` +
                            `(semáforo=${porSemaforo}, autoDeclaration=${porBandera})`);
                anotarBitacora('extracción lista',
                    isAuto ? 'pasa a declarar' : `⚠️ NO pasa (semáforo=${porSemaforo}, bandera=${porBandera})`);

                if (window.sriAssistant) {
                    window.sriAssistant.setWorking(false);
                    window.sriAssistant.log(isAuto ? '🚀 DECLARACIÓN: Extracción Completada.' : '📊 REPORTE: Extracción Finalizada.');
                    window.sriAssistant.updateSummary();

                    if (!isAuto) {
                        // Si es reporte, mostrar un aviso de éxito sin sugerir navegación
                        window.sriAssistant.showEliteToast({
                            title: '📊 Reporte Generado',
                            msg: 'Los datos han sido extraídos. Puedes ver el resumen en el panel o exportar a Excel.',
                            duration: 5000
                        });
                    }
                }
                if (isAuto && window.sriAssistant) {
                    // --- TRANSICIÓN DIRECTA A FASE 2: NAVEGACIÓN (ELITE AUTOMATION) ---
                    // En lugar de solo sugerir, disparamos la navegación si es modo auto
                    window.sriAssistant.log('🚀 FASE 1 OK: Saltando a Navegación del Formulario...');
                    setTimeout(() => {
                        window.sriAssistant.runUnifiedWorkflow('NAVIGATE_AND_FILL', items.workflowPeriod);
                    }, 1000);
                }
                return;
            }
        }
    }

    if (currentAction === 'FIN_TURBO_BULK' || items.pendingAction === 'FIN_TURBO_BULK') {
        const bulkResults = items.bulkFlow?.results || [];

        // Agregación Maestra
        const totals = {
            facturasCount: 0,
            iva15: 0,
            iva0: 0,
            montoIva: 0, // NEW: Sum of IVA from invoices
            totalFacturas: 0, // NEW: Sum of (Base + IVA)
            retCount: 0,
            retIva: 0,
            retIvaBase: 0,
            retRenta: 0,
            retRentaBase: 0,
            ncCount: 0,
            ncIva15: 0,
            ncIva0: 0,
            ncIva: 0, // NEW: Sum of IVA from NC
            ncTotal: 0
        };

        bulkResults.forEach(res => {
            const d = res.data;
            if (d.facturas) {
                totals.facturasCount += d.facturas.totalFacturas || 0;
                totals.iva15 += parseDecimal(d.facturas.iva15?.baseImponible || 0);
                totals.iva0 += parseDecimal(d.facturas.iva0?.baseImponible || 0);
                totals.montoIva += parseDecimal(d.facturas.iva15?.montoIva || 0);
                totals.totalFacturas += parseDecimal(d.facturas.iva15?.total || 0) + parseDecimal(d.facturas.iva0?.total || 0);
            }
            if (d.retenciones) {
                totals.retCount += d.retenciones.totalRetenciones || 0;
                totals.retIva += parseDecimal(d.retenciones.ivaRetenido?.total || 0);
                totals.retIvaBase += parseDecimal(d.retenciones.ivaRetenido?.baseTotal || 0);
                totals.retRenta += parseDecimal(d.retenciones.rentaRetenida?.total || 0);
                totals.retRentaBase += parseDecimal(d.retenciones.rentaRetenida?.baseTotal || 0);
            }
            if (d.notasCredito) {
                totals.ncCount += d.notasCredito.totalNotas || 0;
                totals.ncIva15 += parseDecimal(d.notasCredito.iva15?.baseImponible || 0);
                totals.ncIva0 += parseDecimal(d.notasCredito.iva0?.baseImponible || 0);
                totals.ncIva += parseDecimal(d.notasCredito.iva?.total || 0);
                totals.ncTotal += parseDecimal(d.notasCredito.totalGeneral || 0);
            }
        });

        if (window.sriAssistant) {
            window.sriAssistant.setWorking(false);
            window.sriAssistant.log('🏆 EXTRACCIÓN MASIVA FINALIZADA.');
        }

        showBulkEliteToast(totals, items.bulkFlow, items.workflowPeriod);

        const storage = await SafeStorage.get(['autoDeclaration']);
        const isAuto = (await SriLoop.puedeAvanzar()) || storage.autoDeclaration === true;

        await SafeStorage.remove(['pendingAction', 'bulkFlow', 'sriAutomationPaused']);
        
        if (isAuto) {
            console.log('🔄 Modo Auto activado. Continuando con el lote o cerrando sesión...');
            if (typeof handleBatchNextClient === 'function') {
                const batchNext = await handleBatchNextClient();
                if (!batchNext && typeof cerrarSesionSRI === 'function') {
                    await cerrarSesionSRI();
                }
            } else if (typeof cerrarSesionSRI === 'function') {
                await cerrarSesionSRI();
            }
        }
        
        return;
    }

    // CASO REDIRIGIDO: Directo a Comprobantes Recibidos
    if (items.pendingAction === 'verifyProfile') {
        let targetPeriod = items.workflowPeriod;
        console.log('🔄 verifyProfile redirigiendo directamente a Comprobantes Recibidos (turbo_step1_facturas)...', targetPeriod);
        await SafeStorage.set({
            pendingAction: 'turbo_step1_facturas',
            checkFacturas: true,
            checkRetenciones: true,
            checkNC: true,
            workflowPeriod: targetPeriod,
            autoDeclaration: true,
            sri_auto_mode: true,
            sri_master_switch_on: true,
            sriAutomationPaused: false,
            actionTimestamp: Date.now(),
            skipSafetyCheck: true
        });
        window.location.href = SRI_PUENTE_RECIBIDOS;
        return;
    }

    // CASO 2: Navegación al Formulario IVA Wizard (INDESTRUCTIBLE v9.9)
    if (items.pendingAction === 'startIvaNavigation') {
        console.log(`🔎 Check Navegación: Periodo=${JSON.stringify(items.workflowPeriod)} Host=${window.location.hostname}`);

        // Auto-reparación: Si no hay periodo, usar mes anterior por defecto
        let targetPeriod = items.workflowPeriod;
        if (!targetPeriod) {
            console.warn('⚠️ No se encontró workflowPeriod. Usando Mes Anterior por defecto.');
            const today = new Date();
            const prevMonth = new Date(today.getFullYear(), today.getMonth() - 1, 1);
            targetPeriod = {
                year: prevMonth.getFullYear(),
                monthIndex: prevMonth.getMonth() // 0-11
            };
        }

        if (window.location.hostname.includes('sri.gob.ec')) {
            console.log('🔄 Ejecutando: Navegación IVA 2011 hacia', targetPeriod);
            if (window.__sriNavRunning) {
                console.log('⏩ Navegación ya está en ejecución en esta vista.');
                return;
            }
            window.__sriNavRunning = true;

            if (typeof ejecutarNavegacionDeclaracion === 'function') {
                ejecutarNavegacionDeclaracion(targetPeriod);
            } else {
                console.error('❌ CRÍTICO: ejecutarNavegacionDeclaracion no está definida.');
                if (window.sriAssistant) window.sriAssistant.showEliteToast({ title: 'Error Crítico', msg: 'Falló la carga del motor de navegación.' });
            }
        } else {
            console.warn('⚠️ Hostname no coincide con SRI:', window.location.hostname);
        }
        return;
    }

    // CASO ANULADO: Recuperación de PDF Faltante en Consulta de Documentos
    // 🧾 Recuperar el comprobante de una declaración ya presentada, sin volver
    // a declararla. Cruza a otra aplicación del portal, así que puede tardar
    // varias cargas: refrescamos el reloj para que no la mate la guarda de
    // acciones caducadas mientras el puente SSO hace lo suyo.
    // 🧾 Traer TODOS los comprobantes: el objetivo general del proyecto.
    if (items.pendingAction === 'bajar_todos_comprobantes' && items.bajarTodos) {
        if (!enConsultaDeclaraciones()) {
            console.log('🧾 [TODOS] Esperando llegar a Consulta de declaraciones...');
            await SafeStorage.set({ actionTimestamp: Date.now() });
            return;
        }
        // El asistente de tres pantallas es el mismo que el de una sola
        // recuperación: se reutiliza para llegar a la tabla.
        const listo = await prepararTablaDeclaraciones();
        if (!listo) { await SafeStorage.set({ actionTimestamp: Date.now() }); return; }

        const resumenBarrido = await barrerTodosLosAnios(items.bajarTodos);

        // 🕰️ Marcar el barrido histórico como hecho — pedido por el usuario
        // el 10-sep-2026: «este es un bucle mensual, no es necesario
        // desconfiar de uno mismo en el mes anterior». El barrido de TODOS
        // los años es una puesta al día de una sola vez, no un paso que haga
        // falta repetir cada mes una vez que un cliente ya está al día. Sólo
        // se marca si no quedó ninguna descarga fallida — si algo falló, el
        // próximo mes se vuelve a intentar en vez de darlo por hecho a medias.
        if (items.bajarTodos.ruc && resumenBarrido && (resumenBarrido.fallaron || 0) === 0) {
            const hist = (await SafeStorage.get(['sc_barrido_historico'])).sc_barrido_historico || {};
            hist[items.bajarTodos.ruc] = Date.now();
            await SafeStorage.set({ sc_barrido_historico: hist });
        }

        // 🧾→🚀 Si esto era la etapa previa de un cliente del lote
        // («primero el comprobante, después declarar», 10-sep-2026), no
        // termina acá: sigue con la declaración. `turbo_*` es genérico y
        // redirige solo si hace falta (07/03), pero no se re-evalúa en esta
        // misma carga — sin la navegación explícita, el pendingAction
        // quedaría escrito sin que nada lo mirara hasta el próximo recargo.
        if (items.bajarTodos.continuarCon) {
            const periodoSiguiente = items.bajarTodos.continuarPeriodo ||
                (typeof SriLoop !== 'undefined' ? SriLoop.periodoPorDefecto() : null);
            console.log(`🧾→🚀 [BUCLE] Comprobantes al día. Ahora sí: ${items.bajarTodos.continuarCon}.`);
            await SafeStorage.set({
                pendingAction: items.bajarTodos.continuarCon,
                workflowPeriod: periodoSiguiente,
                actionTimestamp: Date.now(),
                checkFacturas: true, checkRetenciones: true, checkNC: true,
                autoDeclaration: true, sri_auto_mode: true
            });
            await SafeStorage.remove(['bajarTodos']);
            window.location.href = SRI_PUENTE_RECIBIDOS;
            return;
        }

        await SafeStorage.remove(['pendingAction', 'actionTimestamp', 'bajarTodos']);
        return;
    }

    if (items.pendingAction === 'recuperar_comprobante') {
        const listo = await ejecutarRecuperacionComprobante();
        if (!listo) await SafeStorage.set({ actionTimestamp: Date.now() });
        return;
    }

    if (items.pendingAction === 'recoverPDF') {
        console.log('🛑 [SRI ASSISTANT] recoverPDF anulado por el usuario. Limpiando acción pendiente...');
        await SafeStorage.remove(['pendingAction', 'actionTimestamp']);
        return;
    }

    // Otros casos de legado...
    if (items.pendingAction === 'fillSearch' || items.pendingAction === 'fillSearchFacturas' || items.pendingAction === 'fillSearchRetenciones' || items.pendingAction === 'autoFillSearch') {
        const type = items.pendingAction.includes('Retencion') ? 'Retencion' : 'Factura';
        const period = items.workflowPeriod || { year: new Date().getFullYear(), monthIndex: new Date().getMonth() - 1 };

        console.log(`🔄 Ejecutando: Llenar Búsqueda ${type}`);
        await autoLlenarBusqueda({ ...period, tipoComprobante: type, autoClickConsultar: true });
        await SafeStorage.remove(['pendingAction']);
        if (window.sriAssistant) window.sriAssistant.setWorking(false);
    }
}


// Helper de pausa persistente
async function isPaused() {
    const data = await SafeStorage.get('sriAutomationPaused');
    return !!data.sriAutomationPaused;
}



// ============================================
// MODULO DE NAVEGACION Y BUSQUEDA
// ============================================

async function autoLlenarBusqueda(data) {
    // ELITE v14.1: Protección de Fechas Futuras (Global)
    const now = new Date();
    const currYear = now.getFullYear();
    const currMonth = now.getMonth();

    if (data && (parseInt(data.year) > currYear || (parseInt(data.year) === currYear && parseInt(data.monthIndex) >= currMonth))) {
        console.error('🚫 Bloqueo de Seguridad: Intento de búsqueda en periodo futuro/abierto.');
        if (window.sriAssistant) window.sriAssistant.log('🚫 Error: No se pueden extraer datos de periodos futuros o el mes en curso.');
        return { tableFound: false, error: 'Future date' };
    }

    console.log('🚀 Iniciando configuración de búsqueda con:', data);

    // 1. Verificar si estamos en la página correcta, si no, navegar
    const urlActual = window.location.href;
    if (!urlActual.includes('comprobantesRecibidos.jsf')) {
        console.log('🔄 No estamos en Comprobantes Recibidos, intentando navegar...');
        const navegado = await navegarAComprobantes();
        if (!navegado) {
            throw new Error('No se pudo navegar automáticamante. Por favor ve a "Comprobantes electrónicos recibidos" manualmente.');
        }
        await sleep(2000);
    }

    // Si solo queríamos navegar, terminamos aquí
    if (data && data.onlyNavigate) {
        console.log('✅ Navegación completada (modo solo navegación).');
        return { periodo: 'Navegación', tipo: '-' };
    }

    // 2. Extraer año y mes del payload o calcular (fallback)
    let anio, mesIndex;

    if (data && data.year) {
        anio = data.year;
        mesIndex = data.monthIndex;
    } else {
        // Fallback a lógica anterior (mes anterior)
        const ahora = new Date();
        const mesAnterior = new Date(ahora.getFullYear(), ahora.getMonth() - 1, 1);
        anio = mesAnterior.getFullYear();
        mesIndex = mesAnterior.getMonth();
    }

    if (!anio) throw new Error('Año no definido para la búsqueda');

    const meses = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];
    const mesNombre = meses[mesIndex];
    console.log(`📅 Configurando para: ${mesNombre} ${anio}`);

    // 3. Interactuar con los Selects (ID-Based v12.0)
    console.log('🎯 Detectando selectores de búsqueda...');

    // Función helper para obtener selectores por ID (robusto con escaping de JSF)
    const getSelect = (id) => {
        return document.getElementById(id) ||
            document.querySelector(`select[id$="${id.split(':').pop()}"]`);
    };

    // El puente SSO aterriza primero en una URL con ?token= que enseguida
    // redirige a la definitiva. En esa primera carga los selects todavía no
    // existen y esto reventaba como promesa sin capturar. No era un fallo
    // real: era llegar temprano.
    for (let intento = 0; intento < 16; intento++) {
        if (getSelect('frmPrincipal:ano') && getSelect('frmPrincipal:mes')) break;

        // Antes de seguir esperando, mirar si lo que cargó es una CAÍDA del
        // portal. El 09-sep-2026 el SRI devolvía HTTP 500 acá y el bot se
        // quedaba ocho segundos esperando un formulario que no iba a existir,
        // para después recargar y volver a esperar, ocho veces. Cada recarga
        // era una petición más peleando por el mismo lock trabado.
        const salud = (typeof elPortalSeCayo === 'function') ? elPortalSeCayo() : { caido: false };
        if (salud.caido) {
            let quien = {};
            try {
                const it = await SafeStorage.get(['pending_sri_autofill']);
                quien = it.pending_sri_autofill || {};
            } catch (e) { /* sin cliente, igual se maneja */ }
            if (typeof manejarPortalCaido === 'function') {
                await manejarPortalCaido(salud, { ruc: quien.ruc, nombre: quien.name });
            }
            // Si iba a reintentar, la página ya se está recargando y esto no
            // llega a correr. Si se rindió, el lote quedó detenido.
            throw new Error('PORTAL_CAIDO: ' + salud.motivo);
        }

        if (intento === 0) console.log('⏳ Esperando a que cargue el formulario de búsqueda...');
        await sleep(500);
    }

    // Llegar hasta acá con los selectores puestos significa que el portal
    // contestó bien: se olvida cualquier caída anterior.
    if (typeof elPortalVolvio === 'function') await elPortalVolvio();

    const selAnio = getSelect('frmPrincipal:ano') || document.querySelectorAll('select')[0];
    const selMes = getSelect('frmPrincipal:mes') || document.querySelectorAll('select')[1];
    const selDia = getSelect('frmPrincipal:dia') || document.querySelectorAll('select')[2];
    // ID REAL confirmado: frmPrincipal:cmbTipoComprobante (option value="1" = Factura).
    // 'frmPrincipal:tipoComprobante' era una suposición y nunca existió en el DOM.
    const selTipo = getSelect('frmPrincipal:cmbTipoComprobante') ||
                    getSelect('frmPrincipal:tipoComprobante') ||
                    document.querySelector('select.sri-input-combo-tipo-comprobante') ||
                    document.querySelectorAll('select')[3];

    if (!selAnio || !selMes) {
        console.warn(`⚠️ No aparecieron los selectores de Año/Mes en ${location.pathname.split('/').pop()}. ` +
                     'Si el portal está redirigiendo, se resuelve en la próxima carga.');
        throw new Error('No se encontraron los selectores de Año/Mes. Verifica que la página cargó bien.');
    }

    // A. Seleccionar AÑO
    console.log(`📅 Seleccionando año: ${anio}`);
    selAnio.value = anio.toString();
    selAnio.dispatchEvent(new Event('change', { bubbles: true }));
    await sleep(800); // Esperar que JSF/Ajax refresque el mes

    // B. Seleccionar MES (con reintentos por Ajax)
    let mesSeleccionado = false;
    for (let attempt = 0; attempt < 10; attempt++) {
        const currentSelMes = getSelect('frmPrincipal:mes') || document.querySelectorAll('select')[1];
        if (!currentSelMes) { await sleep(300); continue; }

        const opciones = Array.from(currentSelMes.options);
        const opcionMes = opciones.find(opt => {
            const txt = opt.text.trim().toUpperCase();
            return txt === mesNombre.toUpperCase() || txt.includes(mesNombre.toUpperCase());
        });

        if (opcionMes) {
            console.log(`✅ Mes hallado en intento ${attempt + 1}: ${mesNombre}`);
            currentSelMes.value = opcionMes.value;
            currentSelMes.dispatchEvent(new Event('input', { bubbles: true }));
            currentSelMes.dispatchEvent(new Event('change', { bubbles: true }));

            // VERIFICACIÓN ELITE: Esperar y re-verificar que no se haya reseteado por Ajax tardío
            await sleep(600);
            if (currentSelMes.value !== opcionMes.value) {
                console.warn('⚠️ El mes se reseteó tras la selección. Reintentando...');
                currentSelMes.value = opcionMes.value;
                currentSelMes.dispatchEvent(new Event('change', { bubbles: true }));
            }

            mesSeleccionado = true;
            break;
        }
        await sleep(500);
    }
    if (!mesSeleccionado) console.warn(`⚠️ No se pudo seleccionar el mes ${mesNombre}.`);

    // C. Seleccionar DIA -> "Todos"
    if (selDia) {
        const opciones = Array.from(selDia.options);
        const opcionTodos = opciones.find(opt => opt.text.trim().toLowerCase().includes('todos'));
        if (opcionTodos) {
            selDia.value = opcionTodos.value;
        } else {
            selDia.selectedIndex = 0;
        }
        selDia.dispatchEvent(new Event('change', { bubbles: true }));
        await sleep(500);
    }

    // D. Tipo Comprobante
    let tipoDeseado = 'Factura';
    if (data.tipoComprobante === 'Retencion') tipoDeseado = 'Comprobante de Retención';
    if (data.tipoComprobante === 'Nota de Crédito') tipoDeseado = 'Notas de Crédito';

    if (selTipo) {
        const opciones = Array.from(selTipo.options);
        const opcion = opciones.find(opt =>
            opt.text.toLowerCase().includes(tipoDeseado.toLowerCase()) ||
            (tipoDeseado === 'Retencion' && opt.text.toLowerCase().includes('retencion')) ||
            (tipoDeseado === 'Notas de Crédito' && opt.text.toLowerCase().includes('nota'))
        );

        if (opcion) {
            console.log(`✅ Tipo documento: ${opcion.text}`);
            if (selTipo.value !== opcion.value) {
                selTipo.value = opcion.value;
                selTipo.dispatchEvent(new Event('change', { bubbles: true }));
                await sleep(800);
                if (typeof waitForPortal === 'function') {
                    await waitForPortal(3000);
                }
            }
        }
    }

    await sleep(600);

    // CLICK EN BOTÓN CONSULTAR (Opcional según autoClickConsultar)
    if (data.autoClickConsultar === false) {
        console.log('✅ Filtros configurados. Esperando click manual en Consultar.');
        return { tableFound: false };
    }

    console.log('🔎 Buscando botón Consultar...');
    // ID TATUADO OFICIAL CONFIRMADO: frmPrincipal:btnConsultarSinRe (o fallback frmPrincipal:btnConsultar)
    const directBtn = document.getElementById('frmPrincipal:btnConsultarSinRe') || document.getElementById('frmPrincipal:btnConsultar');
    let btnConsultar = (directBtn && esVisible(directBtn)) ? directBtn : null;

    if (!btnConsultar) {
        const botones = soloDelPortal(document.querySelectorAll('button, input[type="submit"], span.ui-button-text'));
        btnConsultar = botones.find(b => {
            const txt = (b.innerText || b.value || b.textContent || "").toUpperCase();
            return txt.includes('CONSULTAR') && esVisible(b);
        });
    }

    if (btnConsultar) {
        // En modo Turbo, guardamos el siguiente estado ANTES de clickear por si hay reload
        if (data.nextStep) {
            console.log(`💾 Guardando siguiente paso Turbo: ${data.nextStep}`);
            await SafeStorage.set({
                pendingAction: data.nextStep,
                actionTimestamp: Date.now(),
                skipSafetyCheck: true
            });
        }

        // ELITE v12.6: Esperar reCAPTCHA antes de disparar el evento si existe widget
        await waitForRecaptchaReady();

        // Esperar que PrimeFaces termine cualquier AJAX previo (actualizaciones en cascada de mes/día)
        for (let w = 0; w < 12; w++) {
            const statusDialog = document.getElementById('popStatusPrime') || document.querySelector('.ui-dialog[id*="popStatusPrime"]');
            const overlay = document.querySelector('.ui-widget-overlay, .ui-blockui');
            const isStatusActive = (statusDialog && statusDialog.style.display !== 'none' && esVisible(statusDialog)) ||
                                   (overlay && overlay.style.display !== 'none' && esVisible(overlay));
            if (!isStatusActive) break;
            await sleep(300);
        }
        await sleep(500); // Margen de estabilidad JSF

        // ELITE v12.7: Marcar mensajes previos como antiguos sin borrar nodos del DOM
        // (Borrar nodos de PrimeFaces con .remove() rompe los updates Ajax del servidor)
        // IMPORTANTE: NO marcar el contenedor raíz #formMessages:messages porque bloquearía sus futuros hijos
        const oldMessages = document.querySelectorAll('.ui-growl-item-container, .ui-messages-info, .ui-messages-warn, .ui-messages-error');
        oldMessages.forEach(m => {
            m.setAttribute('data-sri-old', 'true');
            m.style.opacity = '0.35';
        });

        const dispararClicConsultar = () => {
            const btnActual = document.getElementById('frmPrincipal:btnConsultarSinRe') ||
                              document.getElementById('frmPrincipal:btnConsultar') ||
                              document.querySelector('button[id*="btnConsultar"]') ||
                              soloDelPortal(document.querySelectorAll('button, input[type="submit"]')).find(b =>
                                  (b.innerText || b.value || '').toUpperCase().includes('CONSULTAR') && esVisible(b)
                              ) ||
                              btnConsultar;

            if (!btnActual) {
                console.warn('⚠️ No se encontró botón Consultar en el DOM.');
                return;
            }

            console.log('🎯 [SRI] Clic certero en Consultar:', btnActual.id || btnActual);
            if (window.sriAssistant) {
                window.sriAssistant.log(`🔎 Consultando ${data.tipoComprobante || 'comprobantes'} en el portal SRI...`);
            }
            btnActual.focus();
            btnActual.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true }));
            btnActual.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true }));
            btnActual.click();
        };

        dispararClicConsultar();

        // ESPERAR Y VERIFICAR SI CARGA LA TABLA O MENSAJE VERÍDICO (Skip Captcha)
        console.log('⏳ Esperando respuesta del SRI (Polling fehaciente)...');
        let tableFound = false;

        // Intentar detectar durante 30 segundos (60 intentos x 500ms)
        for (let i = 0; i < 60; i++) {
            await sleep(500);

            // 1. FAST-FAIL VERÍDICO: Verificar si el SRI responde explícitamente con "No existen datos"
            const noDataVerificado = typeof detectarMensajeNoDatosSRI === 'function'
                ? detectarMensajeNoDatosSRI()
                : { encontrado: false };

            if (noDataVerificado.encontrado) {
                console.warn(`⚡ [Fast-Fail Verídico] Mensaje confirmado del SRI: "${noDataVerificado.texto}"`);
                if (window.sriAssistant) {
                    window.sriAssistant.log(`ℹ️ Confirmado por SRI: No existen comprobantes.`);
                }
                return { tableFound: false, noData: true };
            }

            // Detección de Tabla Vacía (PrimeFaces empty message visible)
            const emptyTable = document.querySelector('.ui-datatable-empty-message');
            if (emptyTable && esVisible(emptyTable)) {
                console.warn('⚡ [Fast-Fail Verídico] Tabla vacía de PrimeFaces encontrada.');
                return { tableFound: false, noData: true };
            }

            // 2. DETECCIÓN DE DATOS: Filas reales con información
            const filasConDatos = document.querySelectorAll(
                'table[id*="tablaCompRecibidos"] tbody tr:not(.ui-datatable-empty-message), ' +
                '.ui-datatable-data tr:not(.ui-datatable-empty-message)'
            );
            const numeroCeldas = document.querySelectorAll('td').length;
            const tieneFilasReales = filasConDatos.length > 0 && Array.from(filasConDatos).some(r => r.querySelectorAll('td').length >= 3);

            if (tieneFilasReales || (numeroCeldas > 10 && document.body.innerText.includes('Clave de Acceso'))) {
                console.log(`✅ [SRI] Tabla con datos detectada (Filas: ${filasConDatos.length}, Celdas: ${numeroCeldas}).`);
                if (window.sriAssistant) {
                    window.sriAssistant.log(`✅ Comprobantes encontrados en el portal SRI.`);
                }
                await optimizarTamanoPagina();
                tableFound = true;
                break;
            }

            // 3. REINTENTO INTELIGENTE: Si en 3.5s (i=7), 7.5s (i=15) o 13s (i=26) no hay tabla, ni diálogo de carga, ni mensajes:
            if ((i === 7 || i === 15 || i === 26) && !tableFound) {
                const statusDialog = document.getElementById('popStatusPrime') || document.querySelector('.ui-dialog[id*="popStatusPrime"]');
                const overlay = document.querySelector('.ui-widget-overlay, .ui-blockui');
                const isStatusActive = (statusDialog && statusDialog.style.display !== 'none' && esVisible(statusDialog)) ||
                                       (overlay && overlay.style.display !== 'none' && esVisible(overlay));

                if (!isStatusActive) {
                    const intentoNum = i <= 7 ? 2 : (i <= 15 ? 3 : 4);
                    console.log(`🔄 Reintentando clic en Consultar (intento ${intentoNum})...`);
                    if (window.sriAssistant) {
                        window.sriAssistant.log(`🔄 Reintentando clic en Consultar (${data.tipoComprobante || 'comprobantes'} - intento ${intentoNum})...`);
                    }
                    dispararClicConsultar();
                } else {
                    console.log('⏳ Portal SRI procesando consulta (diálogo de espera activo)...');
                }
            }
        }

        if (tableFound) {
            console.log('✅ Tabla presente. Auto-Skipping Captcha.');
            return { periodo: `${mesNombre} ${anio}`, tipo: 'Documento', tableFound: true };
        }

    } else {
        console.warn('⚠️ No se encontró el botón Consultar');
    }

    // FALLBACK DE SEGURIDAD NATIVO: Si el polling finalizó sin tabla ni mensaje explícito,
    // consultar directamente vía POST al endpoint de TXT oficial del SRI (lnkTxtlistado)
    if (typeof descargarTxtRecibidos === 'function') {
        console.log('🔎 Polling visual sin tabla. Consultando listado TXT oficial del SRI (lnkTxtlistado)...');
        try {
            const codTipo = data.tipoComprobante === 'Retencion' ? '6' : (data.tipoComprobante === 'Nota de Crédito' ? '3' : '1');
            const filasTxt = await descargarTxtRecibidos(codTipo);
            if (Array.isArray(filasTxt)) {
                if (filasTxt.length > 0) {
                    console.log(`✅ [TXT Oficial] Se recuperaron ${filasTxt.length} comprobantes directamente del portal SRI.`);
                    return { periodo: `${mesNombre} ${anio}`, tipo: 'Documento', tableFound: true, desdeTxt: true, filasTxt };
                } else {
                    console.log('ℹ️ [TXT Oficial] Confirmado por respuesta del SRI: 0 comprobantes en este periodo.');
                    return { tableFound: false, noData: true };
                }
            }
        } catch (eTxt) {
            console.warn('⚠️ Falló verificación TXT de respaldo:', eTxt.message);
        }
    }

    console.warn('⚠️ Polling finalizado sin confirmación fehaciente del SRI. No se asumirá 0 a ciegas.');
    return { periodo: `${mesNombre} ${anio}`, tipo: 'Documento', tableFound: false, error: 'timeout_sin_respuesta' };
}

// ============================================================
// ============================================================
// 💎 DYNAMIC ISLAND SUPERIOR (FLUJO 1-CLIC MAESTRO)
// ============================================================
async function renderLoginCockpit(items) {
    if (!isSRILoginPage()) return;

    const oldCockpit = document.getElementById('sri-login-cockpit');
    if (oldCockpit) oldCockpit.remove();
    const existingIsland = document.getElementById('sri-dynamic-island');
    if (existingIsland) existingIsland.remove();

    // Sin esto el cockpit no se dibujaba nunca en el login real: buscaba un
    // input 'usuario' que el SRI no tiene y salía por el return.
    const campos = encontrarCamposLogin();
    const rucInput = campos && campos.ruc;
    const passInput = campos && campos.pass;
    const loginBtn = campos && campos.btn;
    if (!rucInput || !loginBtn) return;

    // Obtener clientes de la memoria local
    const cacheRes = await SafeStorage.get(['sc_clients_cache', 'workflowPeriod', 'flagged_errors', 'selected_period_month', 'selected_period_year']);
    let rawClients = Array.isArray(cacheRes.sc_clients_cache) ? cacheRes.sc_clients_cache : [];
    if (rawClients.length === 0 && typeof fetchClientsDirectly === 'function') {
        rawClients = await fetchClientsDirectly();
    }
    const flaggedErrs = cacheRes.flagged_errors || {};

    const now = new Date();
    let defaultMonth = now.getMonth() - 1;
    let defaultYear = now.getFullYear();
    if (defaultMonth < 0) { defaultMonth = 11; defaultYear--; }
    let targetMonth = cacheRes.selected_period_month !== undefined ? parseInt(cacheRes.selected_period_month) : (cacheRes.workflowPeriod?.monthIndex ?? defaultMonth);
    let targetYear = cacheRes.selected_period_year !== undefined ? parseInt(cacheRes.selected_period_year) : (cacheRes.workflowPeriod?.year ?? defaultYear);

    const monthNames = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];

    const isClientDone = (c, y, m) => {
        if (!c || !c.ruc) return true;
        const targetPeriodStr = `${y}-${(m + 1).toString().padStart(2, '0')}`;
        const decs = Array.isArray(c.declarations || c.sri_declaraciones) ? (c.declarations || c.sri_declaraciones) : [];
        return decs.some(d => {
            if (!d) return false;
            const p = (d.period || '').split(':')[0].trim();
            const matchesPeriod = p.includes(targetPeriodStr) || p === targetPeriodStr;
            if (!matchesPeriod) return false;
            const hasProof = !!(d.proof_file || d.pdfUrl || d.proofFile);
            const isDoneStatus = d.status === 'Completado' || d.status === 'Enviada' || d.status === 'Pagada';
            return hasProof || isDoneStatus;
        });
    };

    const isClientMensualLocal = (c) => {
        if (!c || !c.ruc) return false;
        if (c.isDeleted || c.is_deleted) return false;
        if (c.isActive === false || c.is_active === false) return false;
        const tp = c.tax_profile || c.taxProfile || {};
        const freq = (tp.ivaFrequency || c.iva_frequency || c.ivaFrequency || '').toLowerCase();
        const reg = (c.regime || '').toLowerCase();
        const type = (c.client_type || c.clientType || tp.clientType || '').toLowerCase();
        if (type === 'solo_plan' || c.requires_declarations === false || tp.requiresDeclarations === false) return false;
        if (freq === 'mensual') return true;
        if (freq === 'semestral' || freq === 'ninguno' || freq === 'anual') return false;
        if (reg.includes('popular')) return false;
        if (reg.includes('emprendedor')) return false;
        return true;
    };

    const get9th = (ruc) => (!ruc || ruc.length < 9) ? 99 : (parseInt(ruc.charAt(8), 10) === 0 ? 10 : parseInt(ruc.charAt(8), 10));
    const getDue = (d) => ({ 1: 10, 2: 12, 3: 14, 4: 16, 5: 18, 6: 20, 7: 22, 8: 24, 9: 26, 0: 28, 10: 28 }[d] || 28);
    const sortBy9th = (a, b) => get9th(a.ruc) - get9th(b.ruc);

    const validClients = rawClients.filter(isClientMensualLocal);
    let pendientes = validClients.filter(c => !isClientDone(c, targetYear, targetMonth) && !flaggedErrs[c.ruc]).sort(sortBy9th);

    // Determinar cliente inicial activo: siempre uno de los pendientes por declarar
    let currentClient = null;
    if (items?.pending_sri_autofill?.ruc && pendientes.some(p => p.ruc === items.pending_sri_autofill.ruc)) {
        currentClient = pendientes.find(p => p.ruc === items.pending_sri_autofill.ruc);
    } else if (pendientes.length > 0) {
        currentClient = pendientes[0];
    }

    const island = document.createElement('div');
    island.id = 'sri-dynamic-island';
    island.style.cssText = 'position: fixed; top: 12px; left: 50%; transform: translateX(-50%); z-index: 2147483647; display: flex; align-items: center; gap: 8px; background: rgba(7, 15, 29, 0.94); backdrop-filter: blur(28px); -webkit-backdrop-filter: blur(28px); border: 1px solid rgba(255, 255, 255, 0.12); border-top: 1px solid rgba(0, 168, 150, 0.65); border-radius: 40px; padding: 6px 14px; box-shadow: 0 16px 40px -8px rgba(0, 0, 0, 0.8), 0 0 25px rgba(0, 168, 150, 0.15); font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; color: #f8fafc; white-space: nowrap; max-width: 98vw; overflow-x: auto; scrollbar-width: none; transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);';

    let minibar = document.getElementById('sri-island-minibar');
    if (!minibar) {
        minibar = document.createElement('div');
        minibar.id = 'sri-island-minibar';
        minibar.style.cssText = 'position: fixed; top: 12px; left: 50%; transform: translateX(-50%); z-index: 2147483647; display: none; align-items: center; gap: 8px; background: rgba(7, 15, 29, 0.94); backdrop-filter: blur(28px); -webkit-backdrop-filter: blur(28px); border: 1px solid rgba(255, 255, 255, 0.14); border-top: 1px solid rgba(0, 168, 150, 0.65); border-radius: 40px; padding: 5px 14px; box-shadow: 0 10px 30px rgba(0, 0, 0, 0.7), 0 0 20px rgba(0, 168, 150, 0.15); font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; color: #f8fafc; font-size: 11px; cursor: pointer; transition: all 0.25s cubic-bezier(0.16, 1, 0.3, 1); user-select: none;';
        document.body.appendChild(minibar);
    }

    // Rellenar credenciales si hay cliente
    if (currentClient && rucInput) {
        rucInput.value = currentClient.ruc;
        if (passInput && currentClient.password) passInput.value = currentClient.password;
    }

    const renderIslandInner = () => {
        const isHidden = sessionStorage.getItem('sri_island_hidden') === '1';
        if (isHidden) {
            island.style.display = 'none';
            minibar.style.display = 'flex';
        } else {
            island.style.display = 'flex';
            minibar.style.display = 'none';
        }

        minibar.innerHTML = `
            <div style="display: flex; align-items: center; gap: 7px;">
                <span style="font-size: 13px; filter: drop-shadow(0 0 6px rgba(0,168,150,0.6));">⚡</span>
                <span style="font-weight: 900; font-size: 11px; letter-spacing: 0.05em; background: linear-gradient(135deg, #34d399 0%, #00A896 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">SC TAXPILOT PRO</span>
                <span style="background: rgba(16, 185, 129, 0.15); border: 1px solid rgba(16, 185, 129, 0.35); color: #34d399; font-size: 10px; font-family: monospace; font-weight: 800; padding: 2px 7px; border-radius: 10px;">${pendientes.length} pend.</span>
                <span style="background: rgba(255,255,255,0.08); border: 1px solid rgba(255,255,255,0.15); color: #ffffff; padding: 3px 8px; border-radius: 12px; font-size: 10px; font-weight: 800; margin-left: 2px;">Mostrar ▾</span>
            </div>
        `;

        island.innerHTML = `
            <div style="display: flex; align-items: center; gap: 7px; font-weight: 900; font-size: 11px; letter-spacing: 0.06em; color: #00A896; padding: 2px 4px;">
                <span style="font-size: 13px; filter: drop-shadow(0 0 6px rgba(0,168,150,0.6));">⚡</span>
                <span style="background: linear-gradient(135deg, #34d399 0%, #00A896 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">SC TAXPILOT PRO</span>
            </div>

            <div style="width: 1px; height: 18px; background: rgba(255,255,255,0.12); margin: 0 1px;"></div>

            <!-- Selector de Periodo -->
            <div style="display: flex; align-items: center; gap: 3px;">
                <select id="sri-cockpit-month" style="background: rgba(0,0,0,0.5); border: 1px solid rgba(255,255,255,0.14); color: #fbbf24; padding: 4px 7px; border-radius: 8px; font-size: 11px; font-weight: 800; font-family: monospace; outline: none; cursor: pointer;">
                    ${monthNames.map((m, idx) => `<option value="${idx}" ${idx === targetMonth ? 'selected' : ''}>${m.substring(0, 3).toUpperCase()}</option>`).join('')}
                </select>
                <select id="sri-cockpit-year" style="background: rgba(0,0,0,0.5); border: 1px solid rgba(255,255,255,0.14); color: #fbbf24; padding: 4px 7px; border-radius: 8px; font-size: 11px; font-weight: 800; font-family: monospace; outline: none; cursor: pointer;">
                    ${[2026, 2025, 2024].map(y => `<option value="${y}" ${y === targetYear ? 'selected' : ''}>${y}</option>`).join('')}
                </select>
            </div>

            <div style="width: 1px; height: 18px; background: rgba(255,255,255,0.12); margin: 0 1px;"></div>

            <!-- Selector de Cliente -->
            <div style="display: flex; align-items: center; gap: 6px;">
                <span style="font-size: 12px; opacity: 0.8;">👤</span>
                <select id="sri-cockpit-select" style="max-width: 250px; background: rgba(0,0,0,0.6); border: 1px solid rgba(255,255,255,0.16); color: #ffffff; padding: 5px 10px; border-radius: 10px; font-size: 11.5px; font-weight: 700; outline: none; cursor: pointer; text-overflow: ellipsis;">
                    ${pendientes.map(c => {
                        const isSel = (currentClient && c.ruc === currentClient.ruc) ? 'selected' : '';
                        const d9 = get9th(c.ruc);
                        return `<option value="${c.ruc}" ${isSel}>${c.name || 'Cliente'} (Día ${getDue(d9)})</option>`;
                    }).join('')}
                    ${pendientes.length === 0 ? '<option value="">🎉 Todos al día en este periodo</option>' : ''}
                </select>
                <span id="sri-cockpit-due-badge" style="background: rgba(245, 158, 11, 0.15); border: 1px solid rgba(245, 158, 11, 0.35); color: #fbbf24; font-size: 10px; font-family: monospace; font-weight: 800; padding: 3px 6px; border-radius: 6px; white-space: nowrap;">
                    ${currentClient ? `Día ${getDue(get9th(currentClient.ruc))}` : ''}
                </span>
                <span id="sri-cockpit-count-badge" style="background: rgba(16, 185, 129, 0.15); border: 1px solid rgba(16, 185, 129, 0.35); color: #34d399; font-size: 10px; font-family: monospace; font-weight: 800; padding: 3px 7px; border-radius: 6px; white-space: nowrap;">
                    ${pendientes.length} pend.
                </span>
            </div>

            <div style="width: 1px; height: 18px; background: rgba(255,255,255,0.12); margin: 0 1px;"></div>

            <!-- Cápsula Clave -->
            <div style="display: flex; align-items: center; gap: 5px; background: rgba(0,0,0,0.45); padding: 4px 8px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.1); font-size: 11px;">
                <span id="sri-cockpit-pass-text" style="font-family: monospace; font-size: 11px; color:${currentClient?.password ? '#34d399' : '#f87171'}; font-weight: 700;">
                    ${currentClient?.password ? '••••••••' : 'SIN CLAVE'}
                </span>
                <span id="sri-cockpit-view-pass" style="cursor: pointer; opacity: 0.8; font-size: 12px;" title="Ver/Ocultar clave">👁️</span>
                <span id="sri-cockpit-edit-pass" style="cursor: pointer; opacity: 0.8; font-size: 12px;" title="Editar clave">✏️</span>
            </div>

            <div style="width: 1px; height: 18px; background: rgba(255,255,255,0.12); margin: 0 1px;"></div>

            <!-- ⚡ UN SOLO BOTÓN PRINCIPAL PARA INICIAR EL BUCLE -->
            <button id="sri-cockpit-btn-master-loop" style="background: linear-gradient(135deg, #00A896 0%, #059669 100%); color: #ffffff; border: none; border-radius: 22px; padding: 7px 18px; font-size: 11.5px; font-weight: 900; letter-spacing: 0.04em; cursor: pointer; display: flex; align-items: center; gap: 7px; box-shadow: 0 4px 18px rgba(0, 168, 150, 0.45); white-space: nowrap; transition: all 0.2s;" title="Iniciar el bucle de auto-declaración para todos los pendientes">
                <span style="font-size: 13px;">⚡</span>
                <span>INICIAR BUCLE</span>
                <span style="background: rgba(255,255,255,0.25); color: #ffffff; font-size: 10px; font-family: monospace; font-weight: 900; padding: 1px 6px; border-radius: 10px;">${pendientes.length}</span>
            </button>

            <!-- Botón Omitir Cliente (Saltar cuenta) -->
            <button id="sri-cockpit-btn-skip" style="background: rgba(245, 158, 11, 0.12); border: 1px solid rgba(245, 158, 11, 0.3); color: #fbbf24; border-radius: 20px; padding: 6px 11px; font-size: 11px; font-weight: 700; cursor: pointer; white-space: nowrap; display: flex; align-items: center; gap: 4px; transition: 0.2s;" title="Omitir este cliente si la cuenta está bloqueada o tiene problemas de clave">
                <span>⏭️</span>
                <span>Omitir</span>
            </button>

            <!-- Botón Solo Login (Secundario) -->
            <button id="sri-cockpit-btn-onlylogin" style="background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.12); color: #cbd5e1; border-radius: 20px; padding: 6px 10px; font-size: 11px; font-weight: 700; cursor: pointer; white-space: nowrap; display: flex; align-items: center; gap: 4px; transition: 0.2s;" title="Solo iniciar sesión en el SRI sin declarar automáticamente">
                <span>🔑</span>
                <span>Login</span>
            </button>

            <!-- Botón Lista Completa -->
            <button id="sri-island-toggle-sidebar" style="background: rgba(255, 255, 255, 0.04); border: 1px solid rgba(255, 255, 255, 0.1); color: #94a3b8; border-radius: 20px; padding: 6px 10px; font-size: 10.5px; font-weight: 700; cursor: pointer; white-space: nowrap; display: flex; align-items: center; gap: 4px; transition: 0.2s;" title="Ver/Ocultar lista completa de clientes">
                <span>📋</span>
                <span>Lista</span>
            </button>

            <div style="width: 1px; height: 18px; background: rgba(255,255,255,0.12); margin: 0 1px;"></div>

            <!-- BOTÓN OCULTAR / MINIMIZAR -->
            <button id="sri-island-btn-hide" style="background: rgba(239, 68, 68, 0.08); border: 1px solid rgba(239, 68, 68, 0.25); color: #fca5a5; border-radius: 20px; padding: 5px 11px; font-size: 10.5px; font-weight: 700; cursor: pointer; white-space: nowrap; display: flex; align-items: center; gap: 4px; transition: all 0.2s;" title="Ocultar barra por si vas a hacer otra cosa (Alt + H)">
                <span style="font-size: 10px;">✕</span>
                <span>Ocultar</span>
            </button>
        `;

        // Minimizar / Mostrar
        const hideBtn = island.querySelector('#sri-island-btn-hide');
        hideBtn?.addEventListener('click', () => {
            island.style.display = 'none';
            minibar.style.display = 'flex';
            sessionStorage.setItem('sri_island_hidden', '1');
        });

        minibar.onclick = () => {
            minibar.style.display = 'none';
            island.style.display = 'flex';
            sessionStorage.removeItem('sri_island_hidden');
        };

        // Wire Island Events
        const clientSel = island.querySelector('#sri-cockpit-select');
        const monthSel = island.querySelector('#sri-cockpit-month');
        const yearSel = island.querySelector('#sri-cockpit-year');

        const updateCredentialsInForm = (ruc) => {
            const cl = validClients.find(c => c.ruc === ruc);
            if (cl) {
                currentClient = cl;
                if (rucInput) {
                    rucInput.value = cl.ruc;
                    rucInput.dispatchEvent(new Event('input', { bubbles: true }));
                    rucInput.dispatchEvent(new Event('change', { bubbles: true }));
                }
                if (passInput && cl.password) {
                    passInput.value = cl.password;
                    passInput.dispatchEvent(new Event('input', { bubbles: true }));
                    passInput.dispatchEvent(new Event('change', { bubbles: true }));
                }
                const passText = island.querySelector('#sri-cockpit-pass-text');
                if (passText) {
                    passText.textContent = cl.password ? '••••••••' : 'SIN CLAVE';
                    passText.style.color = cl.password ? '#34d399' : '#f87171';
                }
                const dueBadge = island.querySelector('#sri-cockpit-due-badge');
                if (dueBadge) dueBadge.textContent = `Día ${getDue(get9th(cl.ruc))}`;
            }
        };

        clientSel?.addEventListener('change', (e) => {
            updateCredentialsInForm(e.target.value);
        });

        const onCockpitPeriodChange = async () => {
            targetMonth = parseInt(monthSel.value);
            targetYear = parseInt(yearSel.value);
            await SafeStorage.set({
                selected_period_month: targetMonth,
                selected_period_year: targetYear,
                workflowPeriod: { year: targetYear, monthIndex: targetMonth }
            });
            pendientes = validClients.filter(c => !isClientDone(c, targetYear, targetMonth) && !flaggedErrs[c.ruc]).sort(sortBy9th);
            if (pendientes.length > 0) currentClient = pendientes[0];
            renderIslandInner();
            if (currentClient) updateCredentialsInForm(currentClient.ruc);
        };

        monthSel?.addEventListener('change', onCockpitPeriodChange);
        yearSel?.addEventListener('change', onCockpitPeriodChange);

        // Ver clave
        island.querySelector('#sri-cockpit-view-pass')?.addEventListener('click', () => {
            const passText = island.querySelector('#sri-cockpit-pass-text');
            if (passText && currentClient) {
                if (passText.textContent === '••••••••') passText.textContent = currentClient.password || 'Sin clave';
                else passText.textContent = '••••••••';
            }
        });

        // Editar clave
        island.querySelector('#sri-cockpit-edit-pass')?.addEventListener('click', async () => {
            if (!currentClient) return;
            const newP = prompt(`Ingresa la nueva clave del SRI para ${currentClient.name}:`, currentClient.password || '');
            if (newP === null || newP === currentClient.password) return;
            currentClient.password = newP;
            const cache = await SafeStorage.get(['sc_clients_cache']);
            const list = (cache.sc_clients_cache || []).map(c => c.ruc === currentClient.ruc ? { ...c, password: newP, sri_password: newP } : c);
            await SafeStorage.set({ sc_clients_cache: list });
            updateCredentialsInForm(currentClient.ruc);
            alert('✅ Clave guardada localmente.');
        });

        // ⏭️ OMITIR CLIENTE
        island.querySelector('#sri-cockpit-btn-skip')?.addEventListener('click', async (e) => {
            e.preventDefault();
            if (!currentClient) return;
            const rucToSkip = currentClient.ruc;
            const nameToSkip = currentClient.name || rucToSkip;

            if (confirm(`¿Omitir a ${nameToSkip} (${rucToSkip})?\nSe marcará para no procesarlo en este lote.`)) {
                const resErr = await SafeStorage.get(['flagged_errors']);
                const errs = resErr.flagged_errors || {};
                errs[rucToSkip] = 'omitido_manual';
                await SafeStorage.set({ flagged_errors: errs });
                await SafeStorage.remove(['pending_sri_autofill', 'pendingAction', 'actionTimestamp']);

                // Recargar lista de pendientes
                flaggedErrs[rucToSkip] = 'omitido_manual';
                pendientes = validClients.filter(c => !isClientDone(c, targetYear, targetMonth) && !flaggedErrs[c.ruc]).sort(sortBy9th);
                currentClient = pendientes.length > 0 ? pendientes[0] : null;
                renderIslandInner();
                if (currentClient) updateCredentialsInForm(currentClient.ruc);
                else {
                    if (rucInput) rucInput.value = '';
                    if (passInput) passInput.value = '';
                }

                if (window.sriAssistant && typeof window.sriAssistant.showEliteToast === 'function') {
                    window.sriAssistant.showEliteToast({
                        title: '⏭️ Cliente Omitido',
                        msg: `${nameToSkip} omitido. Cambiando al siguiente...`,
                        duration: 4000
                    });
                }
            }
        });

        // Toggle Sidebar
        island.querySelector('#sri-island-toggle-sidebar')?.addEventListener('click', () => {
            let sb = document.getElementById('sri-anticipacion-sidebar');
            if (!sb && typeof renderAnticipationWidget === 'function') {
                renderAnticipationWidget(items);
                sb = document.getElementById('sri-anticipacion-sidebar');
            }
            if (sb) {
                sb.classList.toggle('collapsed');
            }
        });

        // ⚡ BOTÓN MAESTRO: INICIAR BUCLE AUTOMÁTICO
        island.querySelector('#sri-cockpit-btn-master-loop')?.addEventListener('click', async (e) => {
            e.preventDefault();
            if (pendientes.length === 0) {
                alert('¡🎉 No hay clientes pendientes por declarar en este periodo!');
                return;
            }

            const selectedRuc = clientSel?.value || (currentClient ? currentClient.ruc : '');
            let queue = pendientes.map(c => ({ ruc: c.ruc, password: c.password, name: c.name }));

            // 🕯️ La Lista Bendita decide quién entra al lote desde el HUD también.
            // Sin lista (null) esto no cambia nada. El botón ▶ de un cliente suelto
            // no pasa por acá: es una decisión explícita de una persona.
            queue = await filtrarColaPorBendita(queue);
            if (queue.length === 0 && pendientes.length > 0) {
                alert('🤍 Ninguno de los pendientes está en la Lista Bendita.\n\nAbrí el popup de la extensión, marcá con 🙏 a los que corren y volvé a intentar.');
                return;
            }

            const selIdx = queue.findIndex(c => c.ruc === selectedRuc);
            if (selIdx > 0) {
                queue = [queue[selIdx], ...queue.slice(0, selIdx), ...queue.slice(selIdx + 1)];
            }

            // 🛡️ Filtro de seguridad: excluir cuentas bloqueadas o con credenciales fallidas sin actualizar
            if (typeof SriCredentialVault !== 'undefined') {
                const safeQueue = [];
                for (const q of queue) {
                    const check = await SriCredentialVault.canAttemptLogin(q.ruc, q.password);
                    if (check.allowed) safeQueue.push(q);
                    else console.log(`🛡️ [COCKPIT] Excluyendo ${q.ruc} (${q.name}) del bucle: ${check.reason}`);
                }
                queue = safeQueue;
            }

            if (queue.length === 0) {
                alert('⚠️ Todos los clientes pendientes tienen problemas de credenciales o cuentas bloqueadas en el SRI. Corrige sus claves antes de iniciar.');
                return;
            }

            const first = queue[0];
            if (!first.password) {
                alert(`⚠️ El cliente ${first.name} (${first.ruc}) no tiene clave SRI guardada. Ingrésala usando el icono ✏️ antes de iniciar el bucle.`);
                return;
            }

            updateCredentialsInForm(first.ruc);

            // Encendemos el semáforo y configuramos la cola
            if (typeof SriLoop !== 'undefined' && typeof SriLoop.iniciar === 'function') {
                await SriLoop.iniciar(queue, { year: targetYear, monthIndex: targetMonth });
            }

            await SafeStorage.set({
                sri_master_switch_on: true,
                auto_batch_enabled: true,
                sri_auto_mode: true,
                autoDeclaration: true,
                auto_batch_queue: queue,
                auto_batch_index: 0,
                workflowPeriod: { year: targetYear, monthIndex: targetMonth },
                pending_sri_autofill: {
                    ruc: first.ruc,
                    password: first.password,
                    name: first.name,
                    timestamp: Date.now(),
                    manual: true,
                    isBatch: true,
                    loginAttempted: true
                },
                pendingAction: 'turbo_step1_facturas',
                actionTimestamp: Date.now()
            });

            setTimeout(() => {
                if (loginBtn) loginBtn.click();
                else {
                    const campos = encontrarCamposLogin();
                    if (campos && campos.btn) campos.btn.click();
                }
            }, 300);
        });

        // 🔑 SOLO LOGIN
        island.querySelector('#sri-cockpit-btn-onlylogin')?.addEventListener('click', async (e) => {
            e.preventDefault();
            const selRuc = clientSel?.value || rucInput.value;
            const cl = validClients.find(c => c.ruc === selRuc) || currentClient || { ruc: selRuc, password: passInput?.value || '', name: 'Cliente SRI' };

            // 🛡️ Filtro de seguridad preventivo
            if (typeof SriCredentialVault !== 'undefined') {
                const check = await SriCredentialVault.canAttemptLogin(cl.ruc, cl.password);
                if (!check.allowed) {
                    alert(`🛑 [BLOQUEO PREVENTIVO] ${check.reason}\n\nActualiza la contraseña del cliente usando el icono ✏️ antes de intentar.`);
                    return;
                }
            }

            updateCredentialsInForm(cl.ruc);

            await SafeStorage.set({
                sri_master_switch_on: false,
                auto_batch_enabled: false,
                sri_auto_mode: false,
                autoDeclaration: false,
                pending_sri_autofill: {
                    ruc: cl.ruc,
                    password: cl.password,
                    name: cl.name || 'Cliente SRI',
                    timestamp: Date.now(),
                    manual: true,
                    isBatch: false,
                    loginAttempted: false
                }
            });
            await SafeStorage.remove(['pendingAction']);

            setTimeout(() => loginBtn.click(), 300);
        });
    };

    // Registrar atajo de teclado global Alt+H para ocultar/mostrar
    if (!window.__sri_cockpit_hotkey_registered) {
        window.__sri_cockpit_hotkey_registered = true;
        window.addEventListener('keydown', (e) => {
            if (e.altKey && (e.key === 'h' || e.key === 'H')) {
                e.preventDefault();
                const isl = document.getElementById('sri-dynamic-island');
                const mb = document.getElementById('sri-island-minibar');
                if (isl && mb) {
                    if (isl.style.display === 'none') {
                        isl.style.display = 'flex';
                        mb.style.display = 'none';
                        sessionStorage.removeItem('sri_island_hidden');
                    } else {
                        isl.style.display = 'none';
                        mb.style.display = 'flex';
                        sessionStorage.setItem('sri_island_hidden', '1');
                    }
                }
            }
        });
    }

    renderIslandInner();
    document.body.appendChild(island);
}

function initLoginCockpitWatcher() {
    let attempts = 0;
    const interval = setInterval(async () => {
        attempts++;
        if (isSRILoginPage()) {
            if (!document.getElementById('sri-dynamic-island')) {
                const items = await SafeStorage.get(null);
                await renderLoginCockpit(items);
            }
        }
        if (attempts > 25) clearInterval(interval);
    }, 400);

    try {
        const observer = new MutationObserver(async () => {
            if (isSRILoginPage() && !document.getElementById('sri-dynamic-island')) {
                const items = await SafeStorage.get(null);
                await renderLoginCockpit(items);
            }
        });
        if (document.body) observer.observe(document.body, { childList: true, subtree: true });

        // 🔄 SINCRONIZACIÓN EN TIEMPO REAL: Si se registra o actualiza un cliente en la web
        if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.onChanged) {
            chrome.storage.onChanged.addListener((changes, namespace) => {
                if (namespace === 'local' && (changes.sc_clients_cache || changes.selected_period_month || changes.selected_period_year)) {
                    console.log('🔄 [SRI ELITE] Sincronización en tiempo real: Clientes actualizados desde la web.');
                    if (isSRILoginPage()) {
                        SafeStorage.get(null).then(items => {
                            renderLoginCockpit(items);
                            if (typeof renderAnticipationWidget === 'function') {
                                renderAnticipationWidget(items);
                            }
                        });
                    }
                }
            });
        }
    } catch(e) {}
}
